<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(){
        return view('Admin.DBITOOL.index');
        // echo $req->input('email');
    }

    public function user(){
        return view('User.index');
    }

    public function dbi_home(){
        return view('Admin.DBITOOL.dbi-home');
    }

    public function change_role(){
        return view('Admin.DBITOOL.change-role');
    }

    public function cleanup(){
        return view('Admin.DBITOOL.cleanup');
    }

    public function list_dbi(){
        return view('Admin.DBITOOL.list-dbi');
    }

    public function new_dbi(){
        return view('Admin.DBITOOL.new-dbi');
    }

    public function edit_dbi(){
        return view('Admin.DBITOOL.edit-dbi');
    }

    public function search_dbi(){
        return view('Admin.DBITOOL.search-dbi');
    }

    public function documentation(){
        return view('Admin.DBITOOL.documentation');
    }

    public function show_dbi_source_code(){
        return view('Admin.DBITOOL.show-dbi-source-code');
    }

}

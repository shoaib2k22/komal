<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdministrationController extends Controller
{
        public function register_user(){
            return view('Admin.Administration.register-user');
        }

        public function user_search(){
            return view('Admin.Administration.user-search');
        }

        public function user_edit(){
            return view('Admin.Administration.user-edit');
        }

        public function user_list(){
            return view('Admin.Administration.user-list');
        }

        public function edit_roles(){
            return view('Admin.Administration.edit-roles');
        }

        public function edit_rights(){
            return view('Admin.Administration.edit-rights');
        }

        public function main_menu(){
            return view('Admin.Administration.main-menu');
        }

        public function submenu(){
            return view('Admin.Administration.submenu');
        }

        public function rights(){
            return view('Admin.Administration.rights');
        }

        public function roles(){
            return view('Admin.Administration.roles');
        }

        public function pw_users(){
            return view('Admin.Administration.pw-users');
        }

        public function pw_connects(){
            return view('Admin.Administration.pw-connects');
        }

        public function pw_roles(){
            return view('Admin.Administration.pw-roles');
        }

        public function pw_role_dependencies(){
            return view('Admin.Administration.pw-role-dependencies');
        }

        public function pw_groups(){
            return view('Admin.Administration.pw-groups');
        }

        public function pwservice_password(){
            return view('Admin.Administration.change-pwservice-password');
        }

        public function change_password(){
            return view('Admin.Administration.change-password');
        }

        public function pw_user_edit(){
            return view('Admin.Administration.pw-user-edit');
        }

}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdbmController extends Controller
{
    public function homepage(){
        return view('Admin.ADBM.homepage');
    }

    public function tasks(){
        return view('Admin.ADBM.tasks');
    }
}

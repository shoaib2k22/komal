<!-- Stored in resources/views/child.blade.php -->
 

 
<?php $__env->startSection('title', 'Page Title'); ?>
 
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Admin/child.blade.php ENDPATH**/ ?>
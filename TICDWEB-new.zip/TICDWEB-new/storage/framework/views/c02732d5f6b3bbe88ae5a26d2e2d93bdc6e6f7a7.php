
<?php $__env->startSection('title', 'Page Title'); ?>



<div class="page-wrapper">
    <div class="content container-fluid-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Change Role (Curr. REQ)</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Change Role</li>
					</ol>
				</div>
			</div>
		</div>
		
		<div class="container">
		  <div class="row">
        <div class="col-md-6">
        <form>
          <div class="form-group">
          <label> <b>New Working Role </b></label>
          <hr>
            <label>Change your role to get the corresponding workflow for this role</label>
            <br>
            <div class="row">
              <div class="col-md-2">
                REQ
              </div>
              <div class="col-md-4">
                <input type="radio" name="role" checked><label> &nbsp;Role</label>
              </div>
            </div>
            <hr>
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-danger btn-sm">Change</button>
            <button type="reset" class="btn btn-danger btn-sm">Reset</button>
          </div>
        </form>      
        </div>
      </div>
		</div>
	 </div>
  </div>




<?php echo $__env->make('Admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Admin/DBITOOL/change-role.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'Page Title'); ?>



<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">List MY DBIs</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">List MY DBIs</li>
					</ol>
				</div>
			</div>
		</div>
		
	<div class="container">
            <form>
                <div class="row">
                    <div class="col-md-9">
                        <div class="row">
                            <div class="col-md-2 form-group">
                                <label>Period Days</label>
                            </div>
                            <div class="col-md-6 form-group ">
                                <input type="text" class="form-control" value="90" name="periodays">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 form-group">
                                <label>Refresh [Minutes]</label>
                            </div>
                            <div class="col-md-6 form-group">
                            <input type="text" class="form-control" value="5" name="refreshminutes">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2 form-group">
                                <label>Show DBIs</label>
                            </div> 
                            <div class="col-md-6 form-group">
                                <input type="radio"  value="Waiting DBIs" name="showdbis" ><label>&nbsp; Waiting DBIs</label>
                                <input type="radio"  value="all DBIs" name="showdbis" ><label>&nbsp; All DBIs</label>
                                <input type="radio"  value="only my DBIs" name="showdbis"> <label>&nbsp; Only My DBIs </label>
                            </div>
                        </div> 
                        <div class="row">
                            <div class="col-md-2 form-group">
                                <label>Result Count</label>
                            </div>
                            <div class="col-md-6 form-group">
                            <input type="text" class="form-control" value="15" name="result count">
                            </div>
                        </div>
                        <div class=" form-group">
                            <button class="btn btn-lg btn-danger">Change</button>
                        </div>
                    </div>
                </div>
            </form>
    </div>
    <br>
    <!-- Table -->
    <div class="container">
        <div class="row table-responsive">
            <div class="col-sm-12">
                <div class="card card-table">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Request ID</th>
                                <th>Status</th>
                                <th>Type</th>
                                <th>Category</th>
                                <th>Brief Description</th>
                                <th>Requestor</th>
                                <th>SDE Approval</th>
                                <th>DA Approval</th>
                                <th>Submmitted On</th>
                                <th>Last changed On</th>
                                <th>Operator</th>
                                <th>Priority</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>18304</td>
                                <td>Executed Successfully</td>
                                <td>Recurring</td>
                                <td>Sql Standard</td>
                                <td>TRX_P1 is null for some of the Transactions in CSM_TRANSCTIONS table for ADI.</td>
                                <td>Pachgade, Payal (9168667610) TIMC, Senior executive</td>
                                <td>Joshi, Omkar (4915212819149) TICC, consultant</td>
                                <td>Patil, Rupali (+91 7391085081) TIMD, Senior Executive</td>
                                <td>2018-12-10 13:17:57</td>
                                <td>2023-08-08 09:58:25</td>
                                <td>Pachgade, Payal (9168667610) TIMC, Senior executive</td>
                                <td>Normal</td>
                            </tr>
                            <tr>
                                <td>18304</td>
                                <td>Executed Successfully</td>
                                <td>Recurring</td>
                                <td>Sql Standard</td>
                                <td>TRX_P1 is null for some of the Transactions in CSM_TRANSCTIONS table for ADI.</td>
                                <td>Pachgade, Payal (9168667610) TIMC, Senior executive</td>
                                <td>Joshi, Omkar (4915212819149) TICC, consultant</td>
                                <td>Patil, Rupali (+91 7391085081) TIMD, Senior Executive</td>
                                <td>2018-12-10 13:17:57</td>
                                <td>2023-08-08 09:58:25</td>
                                <td>Pachgade, Payal (9168667610) TIMC, Senior executive</td>
                                <td>Normal</td>
                            </tr>
                            <tr>
                                <td>18304</td>
                                <td>Executed Successfully</td>
                                <td>Recurring</td>
                                <td>Sql Standard</td>
                                <td>TRX_P1 is null for some of the Transactions in CSM_TRANSCTIONS table for ADI.</td>
                                <td>Pachgade, Payal (9168667610) TIMC, Senior executive</td>
                                <td>Joshi, Omkar (4915212819149) TICC, consultant</td>
                                <td>Patil, Rupali (+91 7391085081) TIMD, Senior Executive</td>
                                <td>2018-12-10 13:17:57</td>
                                <td>2023-08-08 09:58:25</td>
                                <td>Pachgade, Payal (9168667610) TIMC, Senior executive</td>
                                <td>Normal</td>
                            </tr>
                            <tr>
                                <td>18304</td>
                                <td>Executed Successfully</td>
                                <td>Recurring</td>
                                <td>Sql Standard</td>
                                <td>TRX_P1 is null for some of the Transactions in CSM_TRANSCTIONS table for ADI.</td>
                                <td>Pachgade, Payal (9168667610) TIMC, Senior executive</td>
                                <td>Joshi, Omkar (4915212819149) TICC, consultant</td>
                                <td>Patil, Rupali (+91 7391085081) TIMD, Senior Executive</td>
                                <td>2018-12-10 13:17:57</td>
                                <td>2023-08-08 09:58:25</td>
                                <td>Pachgade, Payal (9168667610) TIMC, Senior executive</td>
                                <td>Normal</td>
                            </tr>
                            <tr>
                                <td>18304</td>
                                <td>Executed Successfully</td>
                                <td>Recurring</td>
                                <td>Sql Standard</td>
                                <td>TRX_P1 is null for some of the Transactions in CSM_TRANSCTIONS table for ADI.</td>
                                <td>Pachgade, Payal (9168667610) TIMC, Senior executive</td>
                                <td>Joshi, Omkar (4915212819149) TICC, consultant</td>
                                <td>Patil, Rupali (+91 7391085081) TIMD, Senior Executive</td>
                                <td>2018-12-10 13:17:57</td>
                                <td>2023-08-08 09:58:25</td>
                                <td>Pachgade, Payal (9168667610) TIMC, Senior executive</td>
                                <td>Normal</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Table End -->




<?php echo $__env->make('Admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Admin/DBITOOL/list-dbi.blade.php ENDPATH**/ ?>
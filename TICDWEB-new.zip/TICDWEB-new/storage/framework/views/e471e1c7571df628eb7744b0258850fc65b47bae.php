
 
 <?php $__env->startSection('title', 'Page Title'); ?>



<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor"> User Edit</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">User Edit</li>
					</ol>
				</div>
			</div>
		</div>
		
	<div class="container">
        <div class="row">
            <div class="form-heading">
                User Details
            </div>  
            <form action="" method="post">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Last Name <sup class="text-danger">*</sup></label>
                            <input type="text" name="last_name" class="form-control" value="Last Name">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>First Name <sup class="text-danger">*</sup></label>
                            <input type="text" name="first_name" class="form-control" value="First Name">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                         <div class="form-group">
                            <label>Department <sup class="text-danger">*</sup></label>
                            <input type="text" name="department" class="form-control" value="Department">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Company <sup class="text-danger">*</sup></label>
                            <input type="text" name="company" class="form-control" value="Company">
                        </div>
                    </div>        
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Position <sup class="text-danger">*</sup></label>
                            <input type="text" name="position" class="form-control" value="Position">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Roles </label>
                            <input type="text" name="roles" class="form-control" value="Roles" readonly>
                        </div>
                    </div>
                </div>                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Rights </label>
                            <input type="text" name="rights" class="form-control" value="Rights" readonly>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Email <sup class="text-danger">*</sup></label>
                            <input type="text" name="email" class="form-control" value="Email">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                                <label>Mobile </label>
                                <input type="text" name="mobile" class="form-control" value="Mobile">
                            </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                                <label>Login Name </label>
                                <input type="text" name="login_name" class="form-control" value="Login Name" readonly>
                        </div>
                    </div>
                </div> 
                <div class="row">
                    <div class="col-md-6"> 
                        <div class="form-group">
                            <label>LDAP Name </label>
                            <input type="text" name="ladap_name" class="form-control" value="LDAP Name" readonly>
                        </div>
                  </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Level </label>
                            <input type="text" name="level" class="form-control" value="Level" readonly>
                        </div>
                    </div>
                </div>
              
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Logon Attempts </label>
                            <input type="text" name="logon_attempts" class="form-control" value="Logon Attempts" readonly>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Active </label>
                            <input type="text" name="active" class="form-control" value="Active" readonly>
                        </div>
                </div>
             
             
                <div class="form-group">
                    <a href="edit-roles" class="btn btn-danger">Edit Roles</a>
                    <a href="edit-rights" class="btn btn-danger">Edit Rights</a>
                    <button type="submit" class="btn btn-danger">Save</button>
                    <button href="#" class="btn btn-danger">Delete</button>
                </div>
            </form>
        </div>
    </div>
    <hr class="dotted-border">
    <div class="container Reenable-user">
        <div class="btn-label">
             <span>Will set Active='Y' and  Logon Attempts='0'</span>
        </div>
        <button class="btn btn-danger">Reenable User</button>
    </div>
    <hr class="dotted-border">
    <div class="container reset-password">
        <div class="reset-password">
            <form action="" method="post">
                <div class="col-md-5 form-group">
                        <label for="Password">Password <sup class="text-danger">*</sup></label>
                        <input type="password" id="password" class="form-control">
                </div>
                <div class="col-md-5 form-group">
                        <label for="ConfirmPassword"> Confirm Password <sup class="text-danger">*</sup></label>
                        <input type="password" id="ConfirmPassword" class="form-control">
                </div>
                <div class="col-md-5 form-group">
                    <button class="btn btn-danger" type="submit">Reset Password</button>
                </div>
            </form>
        </div>
    </div>




<?php echo $__env->make('Admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Administration/user-edit.blade.php ENDPATH**/ ?>
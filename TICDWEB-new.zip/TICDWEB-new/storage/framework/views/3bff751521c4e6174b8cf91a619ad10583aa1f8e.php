
<?php $__env->startSection('title', 'Page Title'); ?>



<div class="page-wrapper">
    <div class="content container-fluid-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">New DBI</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">New DBI</li>
					</ol>
				</div>
			</div>
		</div>
		
	<div class="container">
        <form>
            <div class="row">
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-2 form-group">
                            <label>DBI Cateroy</label>
                        </div> 
                        <div class="col-md-6 form-group">
                            <input type="radio"  value="SQL (Default)" name="showdbis" ><label>&nbsp; SQL (Default)</label>
                            <input type="radio"  value="External" name="showdbis" ><label>&nbsp; External</label>
                            <input type="radio"  value="Stored Procedure" name="showdbis"> <label>&nbsp; Stored Procedure </label>
                        </div>
                    </div> 
                    <div class="row">
                        <div class="col-md-2 form-group">
                            <label>Priority</label>
                        </div>
                        <div class="col-md-6 form-group ">
                            <select class="form-control" name="priority" id="">
                                <option value="emergency">Emergency</option>
                                <option value="critical">Critical</option>
                                <option value="normal" selected>Normal</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2 form-group">
                            <label>Market</label>
                        </div>
                        <div class="col-md-6 form-group ">
                            <select class="form-control" name="priority" id="">
                                <option value="credit" selected>Credit</option>
                                <option value="debit">Debit</option>
                                <option value="fn">FN</option>
                                <option value="nk">NK</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2 form-group">
                            <label>DBI Type</label>
                        </div>
                        <div class="col-md-6 form-group ">
                            <select class="form-control" name="priority" id="">
                                <option value="One Time" selected>One Time</option>
                                <option value="Recurring">Recurring</option>
                                <option value="Template">Template</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2 form-group">
                            <label>TT Number</label>
                        </div>
                        <div class="col-md-6 form-group ">
                            <input type="text" class="form-control"  name="ttnumber">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2 form-group">
                            <label>Cerf/CR</label>
                        </div>
                        <div class="col-md-6 form-group">
                        <input type="text" class="form-control" name="cerfcr">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-2 form-group">
                            <label>Reference DBI</label>
                        </div>
                        <div class="col-md-6 form-group">
                        <input type="text" class="form-control"  name="referencedbi">
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-2 form-group">
                            <label>Brief Description  <sup class="text-danger">*</sup></label>
                        </div>
                        <div class="col-md-6 form-group">
                    <textarea class="form-control" id="w3review" name="w3review" rows="4" cols="70"></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2 form-group">
                            <label>Problem Description</label>
                        </div>
                        <div class="col-md-6 form-group">
                        <textarea class="form-control" rows="4" cols="70"  name="problemdrescription"></textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2 form-group">
                            <label>Business Impact </label>
                        </div>
                        <div class="col-md-6 form-group">
                        <textarea class="form-control" rows="4" cols="70"  name="businessimpact"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-lg btn-danger">Create</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <br>




<?php echo $__env->make('Admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Admin/DBITOOL/new-dbi.blade.php ENDPATH**/ ?>
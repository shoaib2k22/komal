
 
 <?php $__env->startSection('title', 'Page Title'); ?>



<style>
    /* ------ Table Style------------- */
.thead-danger{
	background-color: #dc3545;
}
/* ------------Table style End ----------- */
</style>

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Choose User Rights (Username)</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Edit Rights</li>
					</ol>
				</div>
            </div>
        </div>
        <div class="container">
            <div class="col-md-6">
            <form action="" method="post">
            <table class="table table-striped table-hover table-responsive">
                <thead>
                    <tr>
                        <th>Right ID</th>
                        <th>Right</th>
                        <th>Right Granted</th>
                    </tr>
                </thead>
                <tbody>
                        <tr>
                            <td>310</td>
                            <td>ADMIN</td>
                            <td><input type="checkbox" value="1"  checked> (From Roles) </td>
                        </tr>
                        <tr>
                            <td>300</td>
                            <td>DBI-TOOL</td>
                            <td><input type="checkbox" value="1" checked>(From Roles)</td>
                        </tr>
                </tbody>
            </table>
            <div class="form-group float-right">
                <button class="btn btn-danger" type="submit">Save</button>
                <button class="btn btn-danger">Back</button>
            </div>
            </form>
            
            </div>
        </div>
	</div>
</div>
		




<?php echo $__env->make('Admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Administration/edit-rights.blade.php ENDPATH**/ ?>
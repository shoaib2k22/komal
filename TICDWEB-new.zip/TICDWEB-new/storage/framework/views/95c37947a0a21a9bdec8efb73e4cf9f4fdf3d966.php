
 
 <?php $__env->startSection('title', 'Page Title'); ?>



<style>
    /* ------ Table Style------------- */
.thead-danger{
	background-color: #dc3545;
}
/* ------------Table style End ----------- */
</style>

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">User List</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">User List</li>
					</ol>
				</div>
			</div>
		</div>
		
	    <br>
    <!-- Table -->
    <div class="container">
        <div class="row table-responsive">
            <p>Please click on  <b>userid</b> to edit the userdata</p>
            <div class="col-sm-12">
                <div class="card card-table">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>UserID</th>
                                <th>Username</th>
                                <th>Firstname</th>
                                <th>Lastname</th>
                                <th>Email</th>
                                <th>Logons</th>
                                <th>Active</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>978</td>
                                <td>aagarwa0</td>
                                <td>Anurag</td>
                                <td>Agrawal</td>
                                <td>anurag.agrawal@vodafone.com</td>
                                <td>0</td>
                                <td>Y</td>
                            </tr>
                            <tr>
                                <td>978</td>
                                <td>aagarwa0</td>
                                <td>Anurag</td>
                                <td>Agrawal</td>
                                <td>anurag.agrawal@vodafone.com</td>
                                <td>0</td>
                                <td>Y</td>
                            </tr>
                            <tr>
                                <td>978</td>
                                <td>aagarwa0</td>
                                <td>Anurag</td>
                                <td>Agrawal</td>
                                <td>anurag.agrawal@vodafone.com</td>
                                <td>0</td>
                                <td>Y</td>
                            </tr>
                            <tr>
                                <td>978</td>
                                <td>aagarwa0</td>
                                <td>Anurag</td>
                                <td>Agrawal</td>
                                <td>anurag.agrawal@vodafone.com</td>
                                <td>0</td>
                                <td>Y</td>
                            </tr>
                        </tbody>
                       
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Table End -->




<?php echo $__env->make('Admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Administration/user-list.blade.php ENDPATH**/ ?>
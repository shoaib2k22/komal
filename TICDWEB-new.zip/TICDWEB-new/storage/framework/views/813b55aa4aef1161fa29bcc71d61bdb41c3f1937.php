
 
 <?php $__env->startSection('title', 'Page Title'); ?>



<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Rights</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item"> Rights</li>
					</ol>
				</div>
			</div>
		</div>
        <div class="container">
            <h4>Add Rights</h4>
            <div class="col-md-5">
                <form action="" method="post">
                    <label>Rights</label>
                    <input type="text" class="form-control" name="rights">
                    <button type="submit" class="btn btn-danger form-group">Add</button>
                </form>
            </div>
        </div>
        <br>
        <div class="container">
            <div class="col-md-6">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Right ID</th>
                            <th>Right</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>310</td>
                            <td>Admin</td>
                            <td>Delete</td>
                        </tr>
                        <tr>
                            <td>300</td>
                            <td>DBI-Tool</td>
                            <td>Delete</td>
                        </tr>
                        <tr>
                            <td>4166</td>
                            <td>DataIntegrityUser</td>
                            <td>Delete</td>
                        </tr>
                        <tr>
                            <td>654</td>
                            <td>Intern</td>
                            <td>Delete</td>
                        </tr>
                        <tr>
                            <td>655</td>
                            <td>Monitor</td>
                            <td>Delete</td>
                        </tr>
                        <tr>
                            <td>656</td>
                            <td>PerfMon</td>
                            <td>Delete</td>
                        </tr>
                        <tr>
                            <td>2577</td>
                            <td>PWAdmin</td>
                            <td>Delete</td>
                        </tr>
                    </tobdy>
                </table>
            </div>
        </div>
    </div>
</div>


            



<?php echo $__env->make('Admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Admin/Administration/rights.blade.php ENDPATH**/ ?>
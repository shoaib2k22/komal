
 
 <?php $__env->startSection('title', 'Page Title'); ?>



<style>
    /* ------ Table Style------------- */
.thead-danger{
	background-color: #dc3545;
}
/* ------------Table style End ----------- */
</style>

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">User Search</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">User Search</li>
					</ol>
				</div>
			</div>
		</div>
        <div class="container">
            <h4>Searh Filters</h4>
            <form action="" method="post">
                <div class="row">
                    <div class="col-md-3 form-group">
                        <label>Login Name</label>
                        <input type="text" class="form-control" name="login_name">
                    </div>
                    <div class="col-md-3 form-group">
                        <label>Phone</label>
                        <input type="text" class="form-control" name="phone">
                    </div>
                    <div class="col-md-3 form-group">
                        <label>Contact ID (numeric)</label>
                        <input type="text" class="form-control" name="contact_id">
                    </div>
                    <div class="col-md-3 form-group">
                        <label>Contact Last Name</label>
                        <input type="text" class="form-control" name="contact_last_name">
                    </div>
                </div>
               <div class="row">
                    <div class="col-md-3 form-group">
                        <label>Mail</label>
                        <input type="text" class="form-control" name="mail">
                    </div>
                    <div class="col-md-3 form-group">
                        <label>Company</label>
                        <input type="text" class="form-control" name="company">
                    </div>
                    <div class="col-md-3 form-group">
                        <label>Department</label>
                        <input type="text" class="form-control" name="department">
                    </div>
                    <div class="col-md-3 form-group">
                        <label>Position</label>
                        <input type="text" class="form-control" name="position">
                    </div>
                </div>
                <span class="text-danger">(Case insensitivity -  wildcards are * _ ? %)</span>
                <div class="col-md-4 form-group">
                    <button type="submit" class="btn btn-danger">Search</button>
                    <button type="reset" class="btn btn-danger">Reset</button>
                </div>
            </form>
        </div>
        <div class="container">
            <div class="table-heading">
                Search  Results (Rows)
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>UserID</th>
                        <th>User Name</th>
                        <th>Login Name</th>
                        <th>Company</th>
                        <th>Department</th>
                        <th>Position</th>
                        <th>Phone</th>
                        <th>Mail</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- After Search rows needs to be generated otherwise needs to be blank table -->
                    <tr>
                        <td><a href="user-edit">1155</a></td>
                        <td>Mohapatra, Anandita</td>
                        <td>amohapa1</td>
                        <td>Vodafone</td>
                        <td>TIMD</td>
                        <td>Assistant Manager</td>
                        <td>+91 9999999999</td>
                        <td>anandita.mohapatra1@vodafone.com</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>


            



<?php echo $__env->make('Admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Administration/user-search.blade.php ENDPATH**/ ?>
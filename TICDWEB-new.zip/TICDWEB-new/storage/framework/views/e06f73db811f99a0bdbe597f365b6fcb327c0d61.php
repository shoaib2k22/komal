







 
 <?php $__env->startSection('title', 'Page Title'); ?>



<style>
    /* ------ Table Style------------- */
.thead-danger{
	background-color: #dc3545;
}
td {
    border:1px solid #fff;
}
/* ------------Table style End ----------- */
</style>

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">PW Dependencies</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">PW Dependencies</li>
					</ol>
				</div>
			</div>
		</div>
        <div class="container">
            <p>The shown as column (horizontally) are used as 'parent' roles.</p>
            <p>The roles shown as rows (vertically) are used  as 'child' roles.</p>
            <p>The parent  role has acces to all connection assigned to any of its child roles.</p>
            <p>To show all of the roles, click <a href="#">here</a>. </p>
            
            <table class="table table-active table-responsive">
                <tr>
                    <td></td>
                    <td>ADBA</td>
                    <td>KIAS ONLINE SELECT</td>
                    <td>TMACT</td>
                    <td>TMAIM</td>
                    <td>TMAR</td>
                    <td>TMBILL</td>
                    <td>TMCON</td>
                    <td>TMCORP</td>
                    <td>TMDWH</td>
                    <td>TMFT</td>
                    <td>TMHA</td>
                    <td>TMINV</td>
                    <td>TMLNS</td>
                    <td>TMMF</td>
                    <td>TMMP</td>
                    <td>TMOA</td>
                    <td>TMPMC</td>
                    <td>TMPS</td>
                    <td>TMRA</td>
                    <td>TMRATE</td>
                    <td>TMSC</td>
                    <td>TMTIO</td>
                    <td>TMUPM</td>
                </tr>
                <tr>
                    <td>All</td>
                    <td>1</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>

                </tr>
                <tr>
                    <td>AMORE API</td>
                    <td></td>
                    <td></td>
                    <td>1</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>1</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            </table>
        </div>
    </div>
</div>


            



<?php echo $__env->make('Admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Administration/pw-role-dependencies.blade.php ENDPATH**/ ?>

 
 <?php $__env->startSection('title', 'Page Title'); ?>



<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Main Menu / Applications</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item"> Submenu</li>
					</ol>
				</div>
			</div>
		</div>
        <div class="container">
            <div class="table-heading">
                Submenus
            </div>
            <div class="col-md-6">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Main Menu</th>
                            <th>Edit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>ADBM-Team</td>
                            <td>Edit Submenu</td>
                        </tr>
                        <tr>
                            <td>Administration</td>
                            <td>Edit Submenu</td>
                        </tr>
                        <tr>
                            <td>DBI Tool</td>
                            <td>Edit Submenu</td>
                        </tr>
                        <tr>
                            <td>DI Tool</td>
                            <td>Edit Submenu</td>
                        </tr>
                        <tr>
                            <td>DM Tool</td>
                            <td>Edit Submenu</td>
                        </tr>
                        <tr>
                            <td>PerfMon</td>
                            <td>Edit Submenu</td>
                        </tr>
                    </tobdy>
                </table>
            </div>
        </div>
    </div>
</div>


            



<?php echo $__env->make('Admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Administration/submenu.blade.php ENDPATH**/ ?>
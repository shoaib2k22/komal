
 
 <?php $__env->startSection('title', 'Page Title'); ?>



<style>
            
.arrow-pointer {
  width: 110;
  height: 50px;
  background: #dc3545;
  position: relative;
  list-style-type: none;
  /* transform: rotate(-45deg); */
  display:inline-block;
  margin: 13px;

  &:after {
    content: '';
    position: absolute;
    left: 0; bottom: 0; width: 0; height: 0;
    border-left: 25px solid #dc3545;
    border-top: 25px solid transparent;
    border-bottom: 25px solid transparent;
  }

  &:before {
    content: '';
    position: absolute;
    right: -25px;
    bottom: 0;
    width: 0;
    height: 0;
    border-left: 25px solid #dc3545;
    border-top: 25px solid transparent;
    border-bottom: 25px solid transparent;
  }


}

.arrow-pointer:hover {
  width: 110;
  height: 50px;
  background: #fff;
  position: relative;
  list-style-type: none;
  /* transform: rotate(-45deg); */
  border: 1px #dc3545 solid;
  display:inline-block;
  margin: 13px;
  &:after {
    content: '';
    position: absolute;
    left: 0; bottom: 0; width: 0; height: 0;
    border-left: 25px solid #fff;
    border-top: 25px solid transparent;
    border-bottom: 25px solid transparent;
  }

  &:before {
    content: '';
    position: absolute;
    right: -25px;
    bottom: 0;
    width: 0;
    height: 0;
    border-left: 23px solid #dc3545;
    border-top: 25px solid transparent;
    border-bottom: 25px solid transparent;
    
  }


}


li > span {
    position: absolute;
    top: 9px;
    left: 22px;
    color: #000;
}
   
.dbi-details > span{
    font-size:16px;
}
.dbi-summary-table{
    width:50%;
}
.table-heading{
    margin-top:15px;
}

</style>

<div class="page-wrapper">
    <div class="content container">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Edit DBI</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Edit DBI</li>
					</ol>
				</div>
			</div>
		</div>
 
    <div class="container">
        <ul class="dbi-status">
            <li class="arrow-pointer"> <span> Show Summery </span>
            </li>
            <li class="arrow-pointer"> <span> Show DBI Source Code </span>
            </li>
            <li class="arrow-pointer"> <span> Execute This DBI </span>
            </li>
            <li class="arrow-pointer"> <span> Check Execution Results </span>
            </li>
            <li class="arrow-pointer"> <span> Change Status / Set on Hold </span>
            </li>
        </ul>

        <div class="dbi-details">
            <h4 class="text-danger">DBI Summary </h4>
            <span class="text-danger">DBI : d24268 |</span>
            <span class="text-danger">Status : Executed Successfully |</span>
            <span class="text-danger">Responsible : finke Christian (3563),  TICC, Application Operation |</span>
            <span class="text-danger">Date : 14/08/2023</span>
            <hr>
        </div>
    </div>
    <div class="dbi-summary-table">
        <div class="table-heading">
            <span> <b>DBI Number: d24268</b></span>
        </div>
        <table class="table table-striped table-hover">
            <tr>
                <td>DBI Category</td>
                <td>Standard SQL</td>
            </tr>
            <tr>
                <td>Status</td>
                <td>Executed Successfully</td>
            </tr>
            <tr>
                <td>Type</td>
                <td>Recurring</td>
            </tr>
            <tr>
                <td>last Operator</td>
                <td>finke Christian (3563)</td>
            </tr>
            <tr>
                <td>Requestor</td>
                <td>finke Christian (3563),  TICC, Application Operation</td>
            </tr>
            <tr>
                <td>DA Approver</td>
                <td>Dhara, Somerita (+91 9607991951) TIDE</td>
            </tr>
            <tr>
                <td>Submitted On</td>
                <td>2018-03-09 11:13:39</td>
            </tr>
            <tr>
                <td>Status Date</td>
                <td>2018-03-09 11:13:39</td>
            </tr>
            <tr>
                <td>Last Change On</td>
                <td>2018-03-09 11:13:39</td>
            </tr>
            <tr>
                <td>Priority</td>
                <td>Normal</td>
            </tr>
            <tr>
                <td>Market</td>
                <td>Debit</td>
            </tr>
            <tr>
                <td>Brief Description</td>
                <td>Initial value of postcard_arrival_ind is not set due to software error</td>
            </tr>
            <tr>
                <td>Problem Description</td>
                <td>Initial value of postcard_arrival_ind is not set due to software error</td>
            </tr>
            <tr>
                <td>Business Impact</td>
                <td>NULL value might cause AR issues</td>
            </tr>
            <tr>
                <td>TT Number</td>
                <td>Z_INC02252592A</td>
            </tr>
            <tr>
                <td>Cerf / CR</td>
                <td>PRT00089652A</td>
            </tr>
            <tr>
                <td>Refernce DBI</td>
                <td></td>
            </tr>
            <tr>
                <td>DBI Instructions</td>
                <td></td>
            </tr>
            <tr>
                <td>Expire On</td>
                <td></td>
            </tr>
            <tr>
                <td>Request Comments</td>
                <td></td>
            </tr>
            <tr>
                <td>Rejection Reason</td>
                <td></td>
            </tr>
            <tr>
                <td>Cancellation Reason</td>
                <td></td>
            </tr>
            <tr>
                <td>Approved Operator</td>
                <td>REQ and SDE</td>
            </tr>
            <tr>
                <td>On Hold</td>
                <td>no</td>
            </tr>

        </table>
        <div class="table-heading">
            <span> <b>Execution Information</b></span>
        </div>
        <table class="table table-striped table-hover">
            <tr>
                <td>ProdInstance</td>
                <td>OL 1</td>
            </tr>
            <tr>
                <td>DB User</td>
                <td>MNDBARW</td>
            </tr>
            <tr>
                <td>Script</td>
                <td>sql/d24268.sql</td>
            </tr>
        </table>
        <div class="table-heading">
            <span> <b>Additional DBI Info</b></span>
        </div>
        <table class="table table-striped table-hover">
            <tr>
                <td>Stage</td>
                <td>DB</td>
                <td>DB User</td>
                <td>Table Name</td>
                <td>info</td>
                <td>Desc</td>
                <td>Area</td>
                <td>Owner</td>
                <td>Second</td>
                <td>SQl</td>
                <td>Exp</td>
                <td>Act</td>
                <td>Id</td>
                <td>Executed</td>
                <td>Sec</td>
            </tr>
            <tr>
                <td>Prod</td>
                <td>OL1</td>
                <td>MNDBARW</td>
                <td>Prepared_Subscriber</td>
                <td><i class="fa fa-info"></i></td>
                <td><i class="fa fa-question-circle"></i></td>
                <td>CSM</td>
                <td>TICC</td>
                <td></td>
                <td>Update</td>
                <td>790</td>
                <td></td>
                <td>7</td>
                <td>2023-08-14 07:25:37</td>
                <td>142</td>
            </tr>
        </table>
        <span><b>1 Rows</b></span>

        <div class="table-heading">
            <span> <b>Temporary Tables</span>
        </div>
        <table class="table table-striped table-hover">
            <tr>
                <td>DB</td>
                <td>DB User</td>
                <td>Table Name</td>
                <td>Temp Type</td>
                <td>Drop Date</td>
                <td>SQL</td>
                <td>Status</td>
            </tr>
            <tr>
                <td>OL1</td>
                <td>TMCON</td>
                <td>DBI_D24268_PRE_SUB_180309</td>
                <td>Regular</td>
                <td>2019-06-23</td>
                <td></td>
                <td></td>
            </tr>
        </table>
        <span><b>1 Rows</b></span>

        <div class="table-heading">
            <span> <b>Crontab Settings</span>
        </div>
        <table class="table table-striped table-hover">
            <tr>
                <td>ID</td>
                <td>On Hold</td>
                <td>Creation Date</td>
                <td>Update Date</td>
                <td>Operator</td>
                <td>Schedule Status</td>
                <td>Schedule Comments</td>
            </tr>
            <tr>
                <td>2159</td>
                <td>N</td>
                <td>2018-05-24 12:23:19</td>
                <td>2018-05-24 12:23:19</td>
                <td>Finke, Christian (3563) TICC</td>
                <td>Completed</td>
                <td>Child process signalled back after completion</td>
            </tr>
        </table>
        <span><b>1 Rows</b></span>

        <div class="table-heading">
            <span> <b>Schedule Time</span>
        </div>
      
    
    <table class="table table-responsive">
        <tr>
            <td>Month</td>
            <td><table><tr><td>JAN</td><td>FEB</td><td>MAR</td><td>APR</td><td>MAY</td>
            <td>JUN</td><td>JUL</td><td>AUG</td><td>SEP</td><td>OKT</td><td>NOV</td><td>DEC</td> 
        </tr>
        <tr>
            <td><input type="checkbox" name="month[]" value="1" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="month[]" value="2" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="month[]" value="3" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="month[]" value="4" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="month[]" value="5" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="month[]" value="6" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="month[]" value="7" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="month[]" value="8" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="month[]" value="9" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="month[]" value="10" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="month[]" value="11" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="month[]" value="12" class="txtBox" checked disabled></td>
        </tr> </table></td>
        </tr>
        <tr class="bgcLightGrey" valign="middle"><td>Date</td><td><table>
            <tr><td align="center">01</td><td align="center">02</td><td align="center">03</td>
            <td align="center">04</td><td align="center">05</td><td align="center">06</td
            td align="center">07</td><td align="center">08</td><td align="center">09</td>
            <td align="center">10</td><td align="center">11</td><td align="center">12</td>
            <td align="center">13</td><td align="center">14</td><td align="center">15</td>
            <td align="center">16</td><td align="center">17</td><td align="center">18</td>
            <td align="center">19</td><td align="center">20</td><td align="center">21</td>
            <td align="center">22</td><td align="center">23</td><td align="center">24</td>
            <td align="center">25</td><td align="center">26</td><td align="center">27</td>
            <td align="center">28</td><td align="center">29</td><td align="center">30</td>
            <td align="center">31</td><tr><td>
                <input type="checkbox" name="date[]" value="1" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="2" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="3" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="4" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="5" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="6" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="7" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="8" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="9" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="10" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="11" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="12" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="13" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="14" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="15" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="16" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="17" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="18" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="19" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="20" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="21" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="22" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="23" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="24" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="25" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="26" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="27" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="28" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="29" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="30" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="date[]" value="31" class="txtBox" checked disabled></td>
            </tr></table></td></tr>
            <tr class="bgcLightGrey" valign="middle"><td>Weekday</td><td>
                <table><tr><td>SUN</td>
                <td>MON</td>
                <td>TUE</td>
                <td>WED</td>
                <td>THD</td>
                <td>FRI</td>
                <td>SAT</td>
            </tr>
            <tr><td><input type="checkbox" name="weekday[]" value="1" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="weekday[]" value="2" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="weekday[]" value="3" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="weekday[]" value="4" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="weekday[]" value="5" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="weekday[]" value="6" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="weekday[]" value="7" class="txtBox" checked disabled></td>
        </tr></table></td></tr>
        <tr class="bgcLightGrey" valign="middle"><td>Hour*</td><td><table>
            <tr><td align="center">00</td><td align="center">01</td>
            <td align="center">02</td><td align="center">03</td>
            <td align="center">04</td><td align="center">05</td>
            <td align="center">06</td><td align="center">07</td>
            <td align="center">08</td><td align="center">09</td>
            <td align="center">10</td><td align="center">11</td>
            <td align="center">12</td><td align="center">13</td>
            <td align="center">14</td><td align="center">15</td>
            <td align="center">16</td><td align="center">17</td>
            <td align="center">18</td><td align="center">19</td>
            <td align="center">20</td><td align="center">21</td>
            
            <td align="center">22</td><td align="center">23</td>
            <tr><td><input type="checkbox" name="hour[]" value="0" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="1" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="2" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="3" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="4" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="5" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="6" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="7" class="txtBox" checked disabled></td>
            <td><input type="checkbox" name="hour[]" value="8" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="9" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="10" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="11" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="12" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="13" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="14" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="15" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="16" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="17" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="18" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="19" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="20" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="21" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="22" class="txtBox" disabled></td>
            <td><input type="checkbox" name="hour[]" value="23" class="txtBox" disabled></td>
        </tr></table></td></tr><tr class="bgcLightGrey" valign="middle"><td>Minute*</td><td><table>
            <tr>
                <td align="center">00</td>
                <td align="center">05</td>
                <td align="center">10</td>
                <td align="center">15</td>
                <td align="center">20</td>
                <td align="center">25</td>
                <td align="center">30</td>
                <td align="center">35</td>
                <td align="center">40</td>
                <td align="center">45</td>
                <td align="center">50</td>
                <td align="center">55</td>
            <tr>
                <td><input type="checkbox" name="minute[]" value="0" class="txtBox" disabled></td>
                <td><input type="checkbox" name="minute[]" value="1" class="txtBox" disabled></td>
                <td><input type="checkbox" name="minute[]" value="2" class="txtBox" disabled></td>
                <td><input type="checkbox" name="minute[]" value="3" class="txtBox" disabled></td>
                <td><input type="checkbox" name="minute[]" value="4" class="txtBox" checked disabled></td>
                <td><input type="checkbox" name="minute[]" value="5" class="txtBox" disabled></td>
                <td><input type="checkbox" name="minute[]" value="6" class="txtBox" disabled></td>
                <td><input type="checkbox" name="minute[]" value="7" class="txtBox" disabled></td>
                <td><input type="checkbox" name="minute[]" value="8" class="txtBox" disabled></td>
                <td><input type="checkbox" name="minute[]" value="9" class="txtBox" disabled></td>
                <td><input type="checkbox" name="minute[]" value="10" class="txtBox" disabled></td>
                <td><input type="checkbox" name="minute[]" value="11" class="txtBox" disabled></td>
            </tr></table></td></tr>
    </table>
    <hr>
    <button class="btn btn-danger">Show Source</button>
    <button class="btn btn-danger">Show Logs</button>
    <button class="btn btn-danger">Show DBI History</button>
    <button class="btn btn-danger">Save / Next</button>


    </div>
    




<?php echo $__env->make('Admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Admin/edit-dbi.blade.php ENDPATH**/ ?>
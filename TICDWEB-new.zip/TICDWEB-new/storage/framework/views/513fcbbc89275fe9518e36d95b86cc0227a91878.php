
 
 <?php $__env->startSection('title', 'Page Title'); ?>



<style>
    /* ------ Table Style------------- */
.thead-danger{
	background-color: #dc3545;
}
/* ------------Table style End ----------- */
</style>

<div class="page-wrapper">
    <div class="content container-fluid-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Documentation</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Documentation</li>
					</ol>
				</div>
			</div>
		</div>
		
	<div class="container">
        <label>Available Documentation</label>
        <div class="col-md-10">
            <table class="table table-hover table-striped">
                <thead class="thead-danger">
                <tr>
                    <td>Docfile</td>
                    <td>Description</td>
                </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><a href="<?php echo e(asset('document/DBI_Web_Tool_Documentation_171108.pdf')); ?>" target="_blank">DBI Web Tool Documentation 171108.pdf</a></td>
                        <td>DBI Tool User Guide</td>
                    </tr>
                    <tr>
                        <td><a href="<?php echo e(asset('document/Quick_Guide_SQL_Standards.pdf')); ?>" target="_blank">Quick Guide SQL Standards.pdf</a></td>
                        <td>SQL Quick Guide</td>
                    </tr>
                    <tr>
                        <td><a href="<?php echo e(asset('document/Guidelines_for_SQL.pdf')); ?>" target="_blank">Guidelines for SQL.pdf</a></td>
                        <td>Guidelines for SQL</td>
                    </tr>
                    <tr>
                        <td><a href="<?php echo e(asset('document/DBI_Procedure_TIC_TIB.pdf')); ?>" target="_blank">DBI Procedure TIC TIB.pdf</a></td>
                        <td>DBI Procedure in TIC and TIB</td>
                    </tr>
                    <tr>
                        <td><a href="<?php echo e(asset('document/Recurring_DBI.pdf')); ?>" target="_blank">Recurring DBI.pdf</a></td>
                        <td>Recurring DBIs</td>
                    </tr>
                    <tr>
                        <td><a href="<?php echo e(asset('document/DBIProcessNonKIAS.pdf')); ?>" target="_blank">DBIProcessNonKIAS.pdf.pdf</a></td>
                        <td>DBI Procedure for NonKias</td>
                    </tr>
                    <tr>
                        <td><a href="<?php echo e(asset('document/DBITool_Gesamt_171108.pdf')); ?>" target="_blank">DBITool Gesamt_171108.pdf</a></td>
                        <td>DBITool_Gesamt</td>
                    </tr>
                    
                </tbody>
                

            </table>
        </div>
    </div>




<?php echo $__env->make('Admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Admin/documentation.blade.php ENDPATH**/ ?>
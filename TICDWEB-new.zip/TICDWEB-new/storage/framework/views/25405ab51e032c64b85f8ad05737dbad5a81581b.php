
 
 <?php $__env->startSection('title', 'Page Title'); ?>



<style>
    /* ------ Table Style------------- */
.thead-danger{
	background-color: #dc3545;
}

/* ------------Table style End ----------- */
</style>

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Register User</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Register User</li>
					</ol>
				</div>
            </div>
        </div>
        <div class="container">
                <div class="form-heading">
                    LDAP User
                </div>  
                <div class="col-md-4">
                    <form action="">
                        <div class="form-group">
                            <label>LDAP userid</label>
                            <input type="text" name="ldap_userid" class="form-control">
                        </div>
                        or
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-danger">Search</button>
                        </div>
                    </form>
                </div>
            <hr>
                
                <div class="form-heading">
                    User Details
                </div>  
                <form action="" method="post">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Last Name <sup class="text-danger">*</sup></label>
                                <input type="text" name="last_name" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>First Name <sup class="text-danger">*</sup></label>
                                <input type="text" name="first_name" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Department <sup class="text-danger">*</sup></label>
                                <input type="text" name="department" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Company <sup class="text-danger">*</sup></label>
                                <input type="text" name="company" class="form-control">
                            </div>
                        </div>        
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Position <sup class="text-danger">*</sup></label>
                                <input type="text" name="position" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Roles </label>
                                <input type="text" name="roles" class="form-control">
                            </div>
                        </div>
                    </div>                
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Rights </label>
                                <input type="text" name="rights" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Email <sup class="text-danger">*</sup></label>
                                <input type="text" name="email" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                    <label>Mobile </label>
                                    <input type="text" name="mobile" class="form-control">
                                </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                    <label>Login Name </label>
                                    <input type="text" name="login_name" class="form-control">
                            </div>
                        </div>
                    </div> 
                    <div class="row">
                        <div class="col-md-4"> 
                            <div class="form-group">
                                <label>LDAP Name </label>
                                <input type="text" name="ladap_name" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Level </label>
                                <input type="text" name="level" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Logon Attempts </label>
                                <input type="text" name="logon_attempts" class="form-control">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Active </label>
                                <input type="text" name="active" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="form-group ml-3">
                        <button type="submit" class="btn btn-danger">Save</button>
                    </div>
                </form>
        </div>
	</div>
</div>




<?php echo $__env->make('Admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Administration/register-user.blade.php ENDPATH**/ ?>

<style> .sidenav {background-color: #cb0505eb;bottom: 0;left: 0;margin-top: 0;position: fixed;top: 63px;transition: all 0.2s ease-in-out 0s;width: 130px;z-index: 1001;}.sidenav a, .dropdown-btn {padding: 6px 8px 6px 16px;text-decoration: none;font-size: 14px;color: #fff;display: block;border: none;background: none;width: 100%;text-align: left;cursor: pointer;outline: none;}.sidenav a:hover, .dropdown-btn:hover {color: #f1f1f1;}.active {background-color: dc3545;color: white;}.dropdown-container {display: none;background-color: #dc3545;padding-left: 8px;}.fa-caret-down {float: right;padding-right: 8px;}@media  screen and (max-height: 450px) {.sidenav {padding-top: 40px;}.sidenav a {font-size: 14px;}}a > i {color: #fff;font-size: 18px;}.dotted-hr{border: 1px dotted #fff;padding:0;margin:0;}.pw-roles{right: 2px;position: absolute;margin: -9px;}</style>

	<div class="sidebar" id="sidebar">
		<div class="sidebar-inner slimscroll">
			<div id="sidebar-menu" class="sidebar-menu">
				<div class="sidenav">
						<!-- <a href="#">ADBM Team</a> -->
						<button class="dropdown-btn">ADBM Team
							<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-container">
							<a href='homepage'><i class="fa fa-desktop"></i></a>
							<p class="sidebar-txt">Homepage</p>
							
							<button class="dropdown-btn"> ADBM Intern 
							<i class="fa fa-caret-down"></i>
							</button>
								<div class="dropdown-container submenu">
										<!-- <hr> -->
								 <a href="tasks"><p class="sidebar-txt">Tasks</p> </a>
								</div>
						</div>

						<button class="dropdown-btn">DBI Tool 
							<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-container">
							<a href='dbi-home'><i class="fa fa-desktop"></i></a>
							<p class="sidebar-txt">DBI Home</p>
								<hr class="dotted-hr">
							<a href="change-role"><i class="fa fa-suitcase"></i></a>
							<p class="sidebar-txt">Change Role (curr. REQ)</p>
								<hr class="dotted-hr">
							<a href="search-dbi"><i class="fa fa-search"></i></a>
							<p class="sidebar-txt">Search DBI</p>
								<hr class="dotted-hr">
							<a href="list-dbi"><i class="fa fa-list"></i></a>
							<p class="sidebar-txt">List My DBIs</p>
								<hr class="dotted-hr">
							<a href="new-dbi"><i class="fa fa-bookmark-o"></i></a>
							<p class="sidebar-txt">New DBI</p>
								<hr class="dotted-hr">
							<a href="cleanup"><i class="fa fa-ticket"></i></a>
							<p class="sidebar-txt">CleanUp</p>
								<hr class="dotted-hr">
							<a href="documentation"><i class="fa fa-info-circle"></i></a>
							<p class="sidebar-txt">Documentation</p>
								<hr class="dotted-hr">
						</div>

						<button class="dropdown-btn">Administration
							<i class="fa fa-caret-down"></i>
						</button>
						<div class="dropdown-container">
							<button class="dropdown-btn">User 
								<i class="fa fa-caret-down"></i>
							</button>
								<div class="dropdown-container">
									<a href="register-user"><i class="fa fa-user"></i></a>
									<p class="sidebar-txt">Register User </p>
									<a href="user-edit"><i class="fa fa-user"></i></a>
									<p class="sidebar-txt">User Edit </p>
									<a href="user-list"><i class="fa fa-list"></i></a>
									<p class="sidebar-txt">User List </p>
									<a href="user-search"><i class="fa fa-search"></i></a>
									<p class="sidebar-txt">User Search </p>
								</div>
							<hr class="dotted-hr">
							<button class="dropdown-btn">Navigation 
								<i class="fa fa-caret-down"></i>
							</button>
								<div class="dropdown-container">
									<a href="main-menu"><i class="fa fa-list"></i></a>
									<p class="sidebar-txt">Main Menu/Applications </p>
									<a href="submenu"><i class="fa fa-list"></i></a>
									<p class="sidebar-txt">Submenus </p>
								</div>
								<hr class="dotted-hr">
							
							<button class="dropdown-btn">Rights & Roles 
								<i class="fa fa-caret-down"></i>
							</button>
								<div class="dropdown-container">
									<a href="rights"><i class="fa fa-file-text"></i></a>
									<p class="sidebar-txt">Rights </p>
									<a href="roles"><i class="fa fa-address-book"></i></a>
									<p class="sidebar-txt">Roles </p>
								</div>
								<hr class="dotted-hr">
							<button class="dropdown-btn">PW Service 
								<i class="fa fa-caret-down"></i>
							</button>
								<div class="dropdown-container">
									<a href="pw-users"><i class="fa fa-user"></i></a>
									<p class="sidebar-txt">PW Users </p>
									<a href="pw-connects"><i class="fa fa-link"></i></a>
									<p class="sidebar-txt">PW Connects </p>
									<button class="dropdown-btn"> <a href="pw-roles" class="pw-roles" style="display:block;">PW Roles </a>
										<i class="fa fa-caret-down"></i>
									</button>
										<div class="drodown-container active ml-3">
										<a href="pw-role-dependencies"><i class="fa fa-user"></i></a>
										<p class="sidebar-txt">PW Roles Dependencies </p>
										</div>
									<a href="pw-groups"><i class="fa fa-group"></i></a>
									<p class="sidebar-txt">PW Groups </p>
								</div>
								<hr class="dotted-hr">
								<a href="pwservice-password">
								<p class="sidebar-txt"> <b>Change PWService Password </b> </p></a>
						</div>
						<div class="logout ml-3">
						<a href="<?php echo e(asset('/')); ?>"><i class="fa fa-sign-out"></i></a>
							<p class="sidebar-txt">Logout </p>
						</div>
				</div>
			</div>
		</div>
	</div>

<script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}
</script><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Admin/includes/sidebar.blade.php ENDPATH**/ ?>
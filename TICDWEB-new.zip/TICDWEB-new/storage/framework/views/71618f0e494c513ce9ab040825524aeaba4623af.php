
 
 <?php $__env->startSection('title', 'Page Title'); ?>



<style>
    /* ------ Table Style------------- */
.thead-danger{
	background-color: #dc3545;
}
/* ------------Table style End ----------- */
</style>

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">PW Users</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">PW Users</li>
					</ol>
				</div>
			</div>
		</div>
        <br>
        <div class="container">
            <div class="table-heading">
                Edit and exisiting user. To add a new userplease use commandline interface
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Name <input name="name" type="text" id="pw_user_name" /></th>
                        <th>Email</th>
                        <th>Key</th>
                        <th>Active</th>
                        <th>Update</th>
                        <th>DBI User</th>
                        <th colspan="4" class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>actsup</td>
                        <td>TICA_Activation_Support.de@vodafone.com</td>
                        <td>58c2ad49</td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>Fucktionuser, Activierung (8223) TISC</td>
                        <td><a href="pw-user-edit">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">Connects</a></td>
                        <td><a href="#">Roles</a></td>
                    </tr>
                    <tr>
                        <td>actsup</td>
                        <td>TICA_Activation_Support.de@vodafone.com</td>
                        <td>58c2ad49</td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>Fucktionuser, Activierung (8223) TISC</td>
                        <td><a href="pw-user-edit">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">Connects</a></td>
                        <td><a href="#">Roles</a></td>
                    </tr>
                    <tr>
                        <td>actsup</td>
                        <td>TICA_Activation_Support.de@vodafone.com</td>
                        <td>58c2ad49</td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>Fucktionuser, Activierung (8223) TISC</td>
                        <td><a href="pw-user-edit">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">Connects</a></td>
                        <td><a href="#">Roles</a></td>
                    </tr>
                    <tr>
                        <td>actsup</td>
                        <td>TICA_Activation_Support.de@vodafone.com</td>
                        <td>58c2ad49</td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>Fucktionuser, Activierung (8223) TISC</td>
                        <td><a href="pw-user-edit">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">Connects</a></td>
                        <td><a href="#">Roles</a></td>
                    </tr>
                    <tr>
                        <td>actsup</td>
                        <td>TICA_Activation_Support.de@vodafone.com</td>
                        <td>58c2ad49</td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>Fucktionuser, Activierung (8223) TISC</td>
                        <td><a href="pw-user-edit">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">Connects</a></td>
                        <td><a href="#">Roles</a></td>
                    </tr>
                    <tr>
                        <td>actsup</td>
                        <td>TICA_Activation_Support.de@vodafone.com</td>
                        <td>58c2ad49</td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>Fucktionuser, Activierung (8223) TISC</td>
                        <td><a href="pw-user-edit">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">Connects</a></td>
                        <td><a href="#">Roles</a></td>
                    </tr>
                </tbody>
              
            </table>
        </div>
    </div>
</div>


            



<?php echo $__env->make('Admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TICDWEB-new\resources\views/Administration/pw-users.blade.php ENDPATH**/ ?>
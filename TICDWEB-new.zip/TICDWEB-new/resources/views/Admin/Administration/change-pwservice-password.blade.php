@extends('Admin.includes.header')
 
 @section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')

<style>
    /* ------ Table Style------------- */
.thead-danger{
	background-color: #dc3545;
}
/* ------------Table style End ----------- */
</style>

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">PWService Password</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">PWService Password</li>
					</ol>
				</div>
			</div>
		</div>
        
        <div class="container">
            <div class="table-heading">
              Change PWService Password
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>System <input name="system" type="text" id="system" /></th>
                        <th>User <input name="user" type="text" id="user" /></th>
                        <th>Category</th>
                        <th>PWD Group</th>
                        <th>Active</th>
                        <th>Last Update</th>
                        <th>Change Type</th>
                        <th>Status</th>
                        <th>Status Date</th>
                        <th colspan="5" class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>ARREP</td>
                    <td>ABHIJEET.VYAS01</td>
                    <td>DB</td>
                    <td></td>
                    <td>T</td>
                    <td>01-FEB-23</td>
                    <td>Y</td>
                    <td></td>
                    <td></td>
                    <td><a href="#">change PWD</a></td>
                  </tr>
                  <tr>
                    <td>ARREP</td>
                    <td>ABHIJEET.VYAS01</td>
                    <td>DB</td>
                    <td></td>
                    <td>T</td>
                    <td>01-FEB-23</td>
                    <td>Y</td>
                    <td></td>
                    <td></td>
                    <td><a href="change-password">change PWD</a></td>
                  </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>


            
@extends('Admin.includes.footer')


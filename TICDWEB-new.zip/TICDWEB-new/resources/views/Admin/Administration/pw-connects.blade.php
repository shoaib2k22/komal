@extends('Admin.includes.header')
 
 @section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">PW Connects</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">PW Users</li>
					</ol>
				</div>
			</div>
		</div>
        <br>
        <div class="container">
            <div class="table-heading">
                Add Connection
            </div>
            <form action="" metho="post">
                <div class="col-md-6">
                    <div class="form-group">
                         <label> Name</label>
                         <input type="text" class="form-control" id="name" name="name">
                    </div>
                   <div class="form-group">
                        <label> User</label>
                        <input type="text" class="form-control" id="user" name="user">
                   </div>
                   <div class="form-group">
                       <label> Pasword Group</label>
                       <input type="text" class="form-control" id="password_group" name="password_group">
                   </div>
                   <div class="form-group">
                       <label> Category</label>
                        <select name="category" id="category" class="form-control">
                            <option value="oracle">Oracle</option>
                            <option value="oracle">Oracle</option>
                            <option value="oracle">Oracle</option>
                        </select>
                   </div>
                    <div class="form-group">
                        <label> Change Type</label>
                        <input type="radio" name="change_type" value="Database & Repository" id="Database & Repository">Database & Repository
                        <input type="radio" name="change_type" value="Repository Only" id="Repository Only">Repository Only
                    </div>
                    <div class="form-group">
                         <label>Change Condition</label>
                         <input type="text" class="form-control" id="change_condition" name="change_condition">
                    </div>
                   <div class="form-group">
                        <label>Password</label>
                        <input type="text" class="form-control" id="password" name="password">
                   </div>
                    <div class="form-group">
                        <button class="btn btn-danger btn-lg" name="submit" type="submit">
                            Add
                        </button>
                    </div>
                </div>
            </form>
        </div>
        <br>
        <div class="container">
            
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>System <input name="system" type="text" id="system" /></th>
                        <th>User <input name="user" type="text" id="user" /></th>
                        <th>Category</th>
                        <th>PWD Group</th>
                        <th>Active</th>
                        <th>Last Update</th>
                        <th>Change Type</th>
                        <th>Status</th>
                        <th>Status Date</th>
                        <th colspan="5" class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>ADANA1</td>
                        <td>Webda</td>
                        <td>Unix</td>
                        <td></td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>N</td>
                        <td></td>
                        <td></td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">User</a></td>
                        <td><a href="#">Roles</a></td>
                        <td><a href="#">To Change By</a></td>
                    </tr>
                    <tr>
                        <td>ADANA1</td>
                        <td>Webda</td>
                        <td>Unix</td>
                        <td></td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>N</td>
                        <td></td>
                        <td></td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">User</a></td>
                        <td><a href="#">Roles</a></td>
                        <td><a href="#">To Change By</a></td>
                    </tr>
                    <tr>
                        <td>ADANA1</td>
                        <td>Webda</td>
                        <td>Unix</td>
                        <td></td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>N</td>
                        <td></td>
                        <td></td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">User</a></td>
                        <td><a href="#">Roles</a></td>
                        <td><a href="#">To Change By</a></td>
                    </tr>
                    <tr>
                        <td>ADANA1</td>
                        <td>Webda</td>
                        <td>Unix</td>
                        <td></td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>N</td>
                        <td></td>
                        <td></td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">User</a></td>
                        <td><a href="#">Roles</a></td>
                        <td><a href="#">To Change By</a></td>
                    </tr>
                    <tr>
                        <td>ADANA1</td>
                        <td>Webda</td>
                        <td>Unix</td>
                        <td></td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>N</td>
                        <td></td>
                        <td></td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">User</a></td>
                        <td><a href="#">Roles</a></td>
                        <td><a href="#">To Change By</a></td>
                    </tr>
                </tbody>
              
            </table>
        </div>
    </div>
</div>


            
@extends('Admin.includes.footer')


@extends('Admin.includes.header')
 
 @section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')

<style>
    /* ------ Table Style------------- */
ul{
    list-style: none;
}
/* ------------Table style End ----------- */
</style>

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Change Password (Username)</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Change Password</li>
					</ol>
				</div>
			</div>
		</div>
        <div class="container">
            <div class="table-heading">
                Type the New Password
            </div>
            <form action="" metho="post">
                <div class="col-md-6">
                    <div class="form-group">
                         <label> Update at :</label>
                         <ul>
                            <li>
                                <input type="radio" id="updated_At" name="updated_At"> 8.00h (tomorrow)
                            </li>
                            <li>
                                <input type="radio" id="updated_At" name="updated_At"> 11.00h (tomorrow)
                            </li>
                            <li>
                                <input type="radio" id="updated_At" name="updated_At"> 14.00h (tomorrow)
                            </li>
                            <li>
                                <input type="radio" id="updated_At" name="updated_At"> 18.00h (today)
                            </li>
                         </ul>

                    </div>
                   <div class="form-group">
                        <label> New Password</label>
                        <input type="password" class="form-control" id="password" name="password">
                   </div>
                   <div class="form-group">
                        <label> Confirm Password</label>
                        <input type="password" class="form-control" id="password" name="password">
                   </div>
                    <div class="form-group">
                        <button class="btn btn-danger btn-lg" name="submit" type="submit">Save</button>
                        <button class="btn btn-danger btn-lg" type="reset">Cancel</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


            
@extends('Admin.includes.footer')


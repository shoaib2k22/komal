@extends('Admin.includes.header')
 
 @section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Choose User Roles (Username)</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Edit Roles</li>
					</ol>
				</div>
            </div>
        </div>
        <div class="container">
            <div class="col-md-6">
            <form action="" method="post">
            <table class="table table-striped table-hover table-responsive">
                <thead>
                    <tr>
                        <th>Role ID</th>
                        <th>Role</th>
                        <th>Role Granted</th>
                    </tr>
                </thead>
                <tbody>
                        <tr>
                            <td>220</td>
                            <td>DAT</td>
                            <td><input type="checkbox" value="1"  checked></td>
                        </tr>
                        <tr>
                            <td>200</td>
                            <td>REQ</td>
                            <td><input type="checkbox" value="1"></td>
                        </tr>
                        <tr>
                            <td>210</td>
                            <td>SDE</td>
                            <td><input type="checkbox" value="1"></td>
                        </tr>
                        <tr>
                            <td>5695</td>
                            <td>rpatil</td>
                            <td><input type="checkbox" value="1"></td>
                        </tr>
                </tbody>
            </table>
            <div class="form-group float-right">
                <button class="btn btn-danger" type="submit">Save</button>
                <button class="btn btn-danger">Back</button>
            </div>
            </form>
            
            </div>
        </div>
	</div>
</div>
		

@extends('Admin.includes.footer')


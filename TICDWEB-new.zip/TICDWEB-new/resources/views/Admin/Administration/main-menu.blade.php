@extends('Admin.includes.header')
 
 @section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Main Menu / Applications</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Main Menu / Applications</li>
					</ol>
				</div>
			</div>
		</div>
        <div class="container">
            <h4>Add Menu Entry</h4>
            <form action="" method="post">
                <div class="row">
                    <div class="col-md-5 form-group">
                        <label>Short Name</label>
                        <input type="text" class="form-control" name="short_name">
                    </div>
                    <div class="col-md-5 form-group">
                        <label>Long Name</label>
                        <input type="text" class="form-control" name="long_name">
                    </div>
                    <div class="col-md-5 form-group">
                        <label>URL</label>
                        <input type="text" class="form-control" name="url">
                    </div>
                    <div class="col-md-5 form-group">
                        <label>Shortcut</label>
                        <input type="text" class="form-control" name="shortcut">
                    </div>
                    <div class="col-md-5 form-group">
                        <label>Order</label>
                        <input type="text" class="form-control" name="order">
                    </div>
                    <div class="col-md-2 form-group">
                        <label>Enabled</label>
                        <input type="checkbox" class="form-control" name="enabled" checked>
                    </div>
                </div>
                <div class="col-md-4 form-group">
                    <button type="submit" class="btn btn-danger">Add</button>
                    <button type="reset" class="btn btn-danger">Cancel</button>
                </div>
            </form>
        </div>
        <br>
        <div class="container">
            <div class="table-heading">
                Click on the short name to edit
            </div>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Short Name</th>
                        <th>Long Name</th>
                        <th>Url</th>
                        <th>Shortcut</th>
                        <th>Order</th>
                        <th>Enabled</th>
                        <th>Required Right</th>
                        <th colspan="3" class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- After Search rows needs to be generated otherwise needs to be blank table -->
                    <tr>
                        <td>Administration</td>
                        <td>Administration</td>
                        <td>admin/index.php</td>
                        <td>ADMIN</td>
                        <td>4</td>
                        <td>1</td>
                        <td></td>
                        <td><a href="#"> <i class="fa fa-edit text-dark mr-2"></i>Edit</a></td>
                        <td><a href="#"> <i class="fa fa-trash text-dark mr-2"></i>Delete</a></td>
                        <td><a href="#"> <i class="fa fa-exchange text-dark mr-2"></i>Change Rights</a></td>
                    </tr>
                    <tr>
                        <td>Administration</td>
                        <td>Administration</td>
                        <td>admin/index.php</td>
                        <td>ADMIN</td>
                        <td>4</td>
                        <td>1</td>
                        <td></td>
                        <td><a href="#"> <i class="fa fa-edit text-dark mr-2"></i>Edit</a></td>
                        <td><a href="#"> <i class="fa fa-trash text-dark mr-2"></i>Delete</a></td>
                        <td><a href="#"> <i class="fa fa-exchange text-dark mr-2"></i>Change Rights</a></td>
                    </tr>
                    <tr>
                        <td>Administration</td>
                        <td>Administration</td>
                        <td>admin/index.php</td>
                        <td>ADMIN</td>
                        <td>4</td>
                        <td>1</td>
                        <td></td>
                        <td><a href="#"> <i class="fa fa-edit text-dark mr-2"></i>Edit</a></td>
                        <td><a href="#"> <i class="fa fa-trash text-dark mr-2"></i>Delete</a></td>
                        <td><a href="#"> <i class="fa fa-exchange text-dark mr-2"></i>Change Rights</a></td>
                    </tr>
                    <tr>
                        <td>Administration</td>
                        <td>Administration</td>
                        <td>admin/index.php</td>
                        <td>ADMIN</td>
                        <td>4</td>
                        <td>1</td>
                        <td></td>
                        <td><a href="#"> <i class="fa fa-edit text-dark mr-2"></i>Edit</a></td>
                        <td><a href="#"> <i class="fa fa-trash text-dark mr-2"></i>Delete</a></td>
                        <td><a href="#"> <i class="fa fa-exchange text-dark mr-2"></i>Change Rights</a></td>
                    </tr>
               </tbody>
            </table>
        </div>
    </div>
</div>


            
@extends('Admin.includes.footer')


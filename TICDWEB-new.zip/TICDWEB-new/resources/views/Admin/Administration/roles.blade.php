@extends('Admin.includes.header')
 
 @section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')

<style>
    /* ------ Table Style------------- */

ul {
    list-style-type:none
}
/* ------------Table style End ----------- */
</style>

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Roles</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item"> Roles</li>
					</ol>
				</div>
			</div>
		</div>
        <div class="container">
            <h4>Add Roles</h4>
            <div class="col-md-5">
                <form action="" method="post">
                    <label>Roles</label>
                    <input type="text" class="form-control" name="Roles">
                    <button type="submit" class="btn btn-danger form-group">Add</button>
                </form>
            </div>
        </div>
        <br>
        <div class="container">
            <div class="col-md-8">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Role ID</th>
                            <th>Role</th>
                            <th>Right</th>
                            <th colspan="2" class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>220</td>
                            <td>DAT</td>
                            <td>
                                <ul>
                                    <li>DBI-Tool</li>
                                    <li>Admin</li>
                                    <li>Intern</li>
                                    <li>Monitor</li>
                                    <li>Perfmon</li>
                                    <li>Useradmin</li>
                                    <li>Pwoperator</li>
                                    <li>DataIntegrityUser</li>
                                </ul>
                            </td>
                            <td>Delete</td>
                            <td>Change Rights</td>
                        </tr>
                        <tr>
                            <td>200</td>
                            <td>REQ</td>
                            <td>
                                <ul>
                                    <li>DBI-Tool</li>
                                </ul>
                            </td>
                            <td>Delete</td>
                            <td>Change Rights</td>
                        </tr>
                        <tr>
                            <td>210</td>
                            <td>SDE</td>
                            <td>
                                <ul>
                                    <li>DBI-Tool</li>
                                </ul>
                            </td>
                            <td>Delete</td>
                            <td>Change Rights</td>
                        </tr>
                        <tr>
                            <td>5695</td>
                            <td>rpatil</td>
                            <td> </td>
                            <td>Delete</td>
                            <td>Change Rights</td>
                        </tr>
                    </tobdy>
                </table>
            </div>
        </div>
    </div>
</div>


            
@extends('Admin.includes.footer')


@extends('Admin.includes.header')
@section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')
<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">PW Groups</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">PW Groups</li>
					</ol>
				</div>
			</div>
		</div>
        <div class="container">
            <div class="table-heading">
                Add Passwod Group
            </div>
            <form action="" metho="post">
                <div class="col-md-6">
                    <div class="form-group">
                         <label> Name</label>
                         <input type="text" class="form-control" id="name" name="name">
                    </div>
                   <div class="form-group">
                        <label> Description</label>
                        <input type="text" class="form-control" id="description" name="description">
                   </div>
                    <div class="form-group">
                        <button class="btn btn-danger btn-lg" name="submit" type="submit">
                            Add
                        </button>
                    </div>
                </div>
            </form>
        </div>
        <br>
        <div class="container">
            
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th colspan="3" class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>ADBMR_ALL</td>
                        <td>Alle adbmr-User</td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Delete</a></td>
                        <td><a href="#">To change By</a></td>
                    </tr>
                    <tr>
                        <td>ADBMR_ALL</td>
                        <td>Alle adbmr-User</td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Delete</a></td>
                        <td><a href="#">To change By</a></td>
                    </tr>
                    <tr>
                        <td>ADBMR_ALL</td>
                        <td>Alle adbmr-User</td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Delete</a></td>
                        <td><a href="#">To change By</a></td>
                    </tr>
                    <tr>
                        <td>ADBMR_ALL</td>
                        <td>Alle adbmr-User</td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Delete</a></td>
                        <td><a href="#">To change By</a></td>
                    </tr>
                    <tr>
                        <td>ADBMR_ALL</td>
                        <td>Alle adbmr-User</td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Delete</a></td>
                        <td><a href="#">To change By</a></td>
                    </tr>
                    <tr>
                        <td>ADBMR_ALL</td>
                        <td>Alle adbmr-User</td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Delete</a></td>
                        <td><a href="#">To change By</a></td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>
</div>


            
@extends('Admin.includes.footer')


@extends('Admin.includes.header')
 
 @section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Edit PW Users</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Edit PW Users</li>
					</ol>
				</div>
			</div>
		</div>
        <br>
        <div class="container">
            <div class="col-md-5">
            <div class="table-heading">
                Change User (UNIX): "1c170ecaa60f042"
            </div>
                <form action="" method="post">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" name="name" class="form-control" value="1c170ecaa60f042">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="text" name="email" class="form-control" value="alfons.wienen@vodafone.com">
                    </div>
                    <div class="form-group">
                        <label>DBI User</label>
                        <select name="dbi-user" id="dbi-user" class="form-control">
                            <option value="">Fucktionuser, Activierung (8223) TISC</option>
                            <option value="">Fucktionuser, Activierung (8223) TISC</option>
                            <option value="">Fucktionuser, Activierung (8223) TISC</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-danger" type="submit">Save</button>
                        <button class="btn btn-danger" type="reset">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
        <br>
        <div class="container">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Name <input name="name" type="text" id="pw_user_name" /></th>
                        <th>Email</th>
                        <th>Key</th>
                        <th>Active</th>
                        <th>Update</th>
                        <th>DBI User</th>
                        <th colspan="4" class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>actsup</td>
                        <td>TICA_Activation_Support.de@vodafone.com</td>
                        <td>58c2ad49</td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>Fucktionuser, Activierung (8223) TISC</td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">Connects</a></td>
                        <td><a href="#">Roles</a></td>
                    </tr>
                    <tr>
                        <td>actsup</td>
                        <td>TICA_Activation_Support.de@vodafone.com</td>
                        <td>58c2ad49</td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>Fucktionuser, Activierung (8223) TISC</td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">Connects</a></td>
                        <td><a href="#">Roles</a></td>
                    </tr>
                    <tr>
                        <td>actsup</td>
                        <td>TICA_Activation_Support.de@vodafone.com</td>
                        <td>58c2ad49</td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>Fucktionuser, Activierung (8223) TISC</td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">Connects</a></td>
                        <td><a href="#">Roles</a></td>
                    </tr>
                    <tr>
                        <td>actsup</td>
                        <td>TICA_Activation_Support.de@vodafone.com</td>
                        <td>58c2ad49</td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>Fucktionuser, Activierung (8223) TISC</td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">Connects</a></td>
                        <td><a href="#">Roles</a></td>
                    </tr>
                    <tr>
                        <td>actsup</td>
                        <td>TICA_Activation_Support.de@vodafone.com</td>
                        <td>58c2ad49</td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>Fucktionuser, Activierung (8223) TISC</td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">Connects</a></td>
                        <td><a href="#">Roles</a></td>
                    </tr>
                    <tr>
                        <td>actsup</td>
                        <td>TICA_Activation_Support.de@vodafone.com</td>
                        <td>58c2ad49</td>
                        <td>Y</td>
                        <td>18-NOV-09</td>
                        <td>Fucktionuser, Activierung (8223) TISC</td>
                        <td><a href="#">Edit</a></td>
                        <td><a href="#">Locks</a></td>
                        <td><a href="#">Connects</a></td>
                        <td><a href="#">Roles</a></td>
                    </tr>
                </tbody>
              
            </table>
        </div>
    </div>
</div>


            
@extends('Admin.includes.footer')


@extends('Admin.includes.header')
 
 @section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">User List</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">User List</li>
					</ol>
				</div>
			</div>
		</div>
		
	    <br>
    <!-- Table -->
    <div class="container">
        <div class="row table-responsive">
            <p>Please click on  <b>userid</b> to edit the userdata</p>
            <div class="col-sm-12">
                <div class="card card-table">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>UserID</th>
                                <th>Username</th>
                                <th>Firstname</th>
                                <th>Lastname</th>
                                <th>Email</th>
                                <th>Logons</th>
                                <th>Active</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>978</td>
                                <td>aagarwa0</td>
                                <td>Anurag</td>
                                <td>Agrawal</td>
                                <td>anurag.agrawal@vodafone.com</td>
                                <td>0</td>
                                <td>Y</td>
                            </tr>
                            <tr>
                                <td>978</td>
                                <td>aagarwa0</td>
                                <td>Anurag</td>
                                <td>Agrawal</td>
                                <td>anurag.agrawal@vodafone.com</td>
                                <td>0</td>
                                <td>Y</td>
                            </tr>
                            <tr>
                                <td>978</td>
                                <td>aagarwa0</td>
                                <td>Anurag</td>
                                <td>Agrawal</td>
                                <td>anurag.agrawal@vodafone.com</td>
                                <td>0</td>
                                <td>Y</td>
                            </tr>
                            <tr>
                                <td>978</td>
                                <td>aagarwa0</td>
                                <td>Anurag</td>
                                <td>Agrawal</td>
                                <td>anurag.agrawal@vodafone.com</td>
                                <td>0</td>
                                <td>Y</td>
                            </tr>
                        </tbody>
                       
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Table End -->

@extends('Admin.includes.footer')


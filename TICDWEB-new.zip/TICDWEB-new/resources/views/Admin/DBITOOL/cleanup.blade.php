@extends('Admin.includes.header')
 
 @section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')

<style>
  .cleanup-hr{
    border: 1px solid red;
    width: 37%;
  }
</style>
<div class="page-wrapper">
    <div class="content container">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Cleanup Temporary Tables</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">CleanUp</li>
					</ol>
				</div>
			</div>
		</div>
		<div class="container">
        <form>
          <div class="form-group">
          <label> <b> Select Instance </b></label>
              <div class="row">
               <div class="col-md-12">
          <hr class="cleanup-hr">
                <div class="col-md-4">
                    Instance
                </div>
                <div class="col-md-4">
                  <select class="form-control">
                    <option>Select</option>
                    <option value="CMAAC">CMAAC</option>
                    <option value="CMAX">CMAX</option>
                   </select>
                </div>
            <hr class="cleanup-hr">
              </div>
              </div>
            </div>
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-danger btn-sm">Select</button>
          </div>
        </form>      
	 </div>
  </div>

@extends('Admin.includes.footer')


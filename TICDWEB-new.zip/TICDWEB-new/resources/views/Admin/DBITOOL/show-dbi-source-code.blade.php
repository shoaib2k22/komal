@extends('Admin.includes.header')
@section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')

<style> .arrow-pointer {width: 110;height: 50px;background: #dc3545;border:#dc3545;position: relative;list-style-type: none;display:inline-block;margin: 13px;&:after {content: '';position: absolute;left: 0;bottom: 0;width: 0;height: 0;border-left: 25px solid #dc3545;border-top: 25px solid transparent;border-bottom: 25px solid transparent;}&:before {content: '';position: absolute;right: -25px;bottom: 0;width: 0;height: 0;border-left: 25px solid #dc3545;border-top: 25px solid transparent;border-bottom: 25px solid transparent;}}li > span {position: absolute;top: 9px;left: 22px;color: #fff;}.dbi-details > span{font-size:16px;}.dbi-summary-table{width:50%;}.table-heading{margin-top:15px;}</style>

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Edit DBI</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Edit DBI</li>
					</ol>
				</div>
			</div>
		</div>
 
    <div class="container">
        <ul class="dbi-status">
            <li class="arrow-pointer"> <span> Show Summery </span>
            </li>
            <li class="arrow-pointer"> <span> Show DBI Source Code </span>
            </li>
            <li class="arrow-pointer"> <span> Execute This DBI </span>
            </li>
            <li class="arrow-pointer"> <span> Check Execution Results </span>
            </li>
            <li class="arrow-pointer"> <span> Change Status / Set on Hold </span>
            </li>
        </ul>

        <div class="dbi-details">
            <h4 class="text-danger">Show Source</h4>
            <span class="text-danger">DBI : d24268 |</span>
            <span class="text-danger">Status : Executed Successfully |</span>
            <span class="text-danger">Responsible : finke Christian (3563),  TICC, Application Operation |</span>
            <span class="text-danger">Date : 14/08/2023</span>
            <hr>
        </div>

        <div class="container">
            <button type="submit" class="btn btn-danger"> Save/Next</button>
            <button class="btn btn-danger"> Back </button>
        </div>
    </div>
    
    

@extends('Admin.includes.footer')


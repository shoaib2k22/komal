@extends('Admin.includes.header')
 @section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">DBI Home</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">DBI Home</li>
					</ol>
				</div>
			</div>
		</div>
	
		<div class="container">
		  <div class="row">
        <div class="col-md-4">
        <form>
          <div class="form-group">
            <label> <b>Create a New DBI </b></label>
            <!-- <input type="text" class="form-control"> -->
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-danger btn-sm">New DBI</button>
          </div>
        </form>
        <hr>
        <form>
          <div class="form-group">
            <label> <b>Search a DBI </b></label>
            <!-- <input type="text" class="form-control"> -->
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-danger btn-sm">Search DBI</button>
          </div>
        </form>
        <hr>
        <form>
          <div class="form-group">
            <label for="EmailInput1"> <b>Goto /Edit DBI </b></label>
            <!-- <input type="text" class="form-control"> -->
          </div>
          <div class="form-group">
            <a href="edit-dbi"  class="btn btn-danger btn-sm">Edit DBI</a>
          </div>
        </form>
        <hr>
        <form>
          <div class="form-group">
            <label for="EmailInput1"> <b>List DBIs (Waiting, all or only DBIs) </b></label>
            <!-- <input type="text" class="form-control"> -->
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-danger btn-sm">List DBI</button>
          </div>
        </form>
        <hr>
        <form>
          <div class="form-group">
            <label> <b> Create a Copy DBI </b></label>
            <!-- <input type="text" class="form-control"> -->
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-danger btn-sm">Copy DBI</button>
          </div>
        </form>
        <hr>
        </div>
      </div>
		</div>
	 </div>
  </div>

@extends('Admin.includes.footer')


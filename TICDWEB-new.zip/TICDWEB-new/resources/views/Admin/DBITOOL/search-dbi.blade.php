@extends('Admin.includes.header')
@section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Search DBI</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Search DBI</li>
					</ol>
				</div>
			</div>
		</div>
		
	<div class="container">
            <form style="width:80%">
		<div class="row">
            <label> <b>Search Filters </b></label>
            <div class="col-md-5">
                    <div class="form-group">
                        <label>DBI Number</label>
                        <input type="text" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Category</label>
                        <select class="form-control">
                            <option>Select</option>
                            <option value="Sql Standard">Sql Standard</option>
                            <option value="External">External</option>
                            <option value="Procedure">Procedure</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Cerf/CR ID</label>
                        <input type="text" class="form-control" name="cerfcrid">
                    </div>
                    <div class="form-group">
                        <label>Production Execution Data <i>(YYYY-MM-DD)</i></label>
                        <input type="text" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Operator <i>(Name, Department..)</i></label>
                        <input type="text" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Priorioty</label>
                        <select class="form-control">
                            <option>Select</option>
                            <option value="Emergency">Emergency</option>
                            <option value="Critical">Critical</option>
                            <option value="Normal">Normal</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select class="form-control">
                            <option>Select</option>
                            <option value="Aborted">Aborted</option>
                            <option value="Cancelled">Cancelled</option>
                            <option value="Closed">Closed</option>
                            <option value="Closed">Closed</option>
                            <option value="Compiled Successfully">Compiled Successfully</option>
                            <option value="DA Approved">DA Approved</option>
                            <option value="Executed Successfully">Executed Successfully</option>
                            <option value="Failed">Failed</option>
                            <option value="New">New</option>
                            <option value="Open">Open</option>
                            <option value="Rejected">Rejected</option>
                            <option value="Running">Running</option>
                            <option value="SDE Approved">SDE Approved</option>
                            <option value="Send To Approve">Send To Approve</option>
                            <option value="Tested Successfully">Tested Successfully</option>
                            <option value="Undo">Undo</option>
                        </select>
                    </div>
                    
            </div>
            <div class="col-md-5">
                    <div class="form-group">
                        <label>Type</label>
                        <select class="form-control">
                            <option>Select</option>
                            <option value="One-Time">One-Time</option>
                            <option value="Recurring">Recurring</option>
                            <option value="Template">Template</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Requestor <i>(Name, Department..)</i></label>
                        <input type="text" class="form-control">
                    </div>
                 <div class="form-group">
                    <label>Database</label>
                    <select class="form-control">
                        <option>Select</option>
                        <option value="BAT">BAT</option>
                        <option value="CCBELSAA">CCBELSAA</option>
                        <option value="CCB_CI">CCB_CI</option>
                        <option value="CCSDB">CCSDB</option>
                        <option value="CDRCOL">CDRCOL</option>
                        <option value="CLRDB">CLRDB</option>
                        <option value="CMAAC">CMAAC</option>
                        <option value="CMAX">CMAX</option>
                        <option value="DBIEST">DBIEST</option>
                        <option value="DEIOMGA">DEIOMGA</option>
                        <option value="DEM">DEM</option>
                        <option value="DEPAIR">DEPAIR</option>
                        <option value="DEPBWC">DEPBWC</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>SDE <i>(Name, Department..)</i></label>
                    <input type="text" class="form-control">
                </div>
                <div class="form-group">
                    <label>Table:</label>
                    <textarea cols="20" rows="10" class="form-control"></textarea>
                </div>
                <div class="form-group">
                    <label>DA <i>(Name, Department..)</i></label>
                    <input type="text" class="form-control">
                </div>
                
            </div>
	    </div>
        <hr>
        <p>(case insensitivity - wildcards are * _ ? %)</p>
        <div class="col-md-12">
        <div class="form-group">
                    <button type="submit" class="btn btn-danger btn-sm">Start Search</button>
                    <button type="reset" class="btn btn-danger btn-sm">Reset</button>
       </div>
        </div>
        </form>      

    </div>

@extends('Admin.includes.footer')


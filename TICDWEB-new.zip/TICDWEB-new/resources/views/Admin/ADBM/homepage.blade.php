@extends('Admin.includes.header')
 
 @section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')

<style>
    /* ------ Table Style------------- */
.table-heading{
    padding: 14px;
}
/* ------------Table style End ----------- */
</style>

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Tasks</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Tasks</li>
					</ol>
				</div>
			</div>
		</div>
		
	<div class="container">
            <h3>Homepage</h3>
            <hr>
            <div class="table-heading">
                Welcome to TICD - Application Database Management WebPages <br>
                We are the database specialists
            </div>
            
    </div>
   

@extends('Admin.includes.footer')


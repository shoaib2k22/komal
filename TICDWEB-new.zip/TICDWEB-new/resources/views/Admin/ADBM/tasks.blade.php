@extends('Admin.includes.header')
 
 @section('title', 'Page Title')
@extends('Admin.includes.topbar')
@extends('Admin.includes.sidebar')

<style>
    /* ------ Table Style------------- */
.table-heading{
    padding: 14px;
}
/* ------------Table style End ----------- */
</style>

<div class="page-wrapper">
    <div class="content container-fluid">
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Tasks</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Tasks</li>
					</ol>
				</div>
			</div>
		</div>
		
	<div class="container">
            <h3>Open Tasks {{now()->format('d M y') .' '. now()->format('H:i:s')}}</h3>
            <hr>
            <div class="text-center table-heading">
             0 DBI, Waiting  for DA-Approval
            </div>
                <table class="table table-striped table-hover">
                    <tr>
                        <th>DBI</th>
                        <th>Requestor</th>
                        <th>SDE Approval</th>
                        <th>Submitted On</th>
                        <th>SDE Approved On</th>
                        <th>Priority</th>
                    </tr>
                    <tr>
                        <td><a href="#">d26472</a></td>
                        <td>Naik, Sameer (7391097349)</td>
                        <td>Gaiwale,Chandrakant (+919923376897)</td>
                        <td>2023-08-28 08:53:47</td>
                        <td>2023-08-28 09:09:35</td>
                        <td>Normal</td>
                    </tr>
                </table>
            <hr>
            <div class="troubletickets">
            <div class="text-center table-heading">
             TTWOS State per 2023-08-18  11:45:10
             <br>
             16 open Troubletickets
            </div>
            <table class="table table-striped table-hover">
                <tr>
                    <th>ToDo</th>
                    <th>TT Number</th>
                    <th>State</th>
                    <th>User</th>
                    <th>Team</th>
                    <th>Priority</th>
                    <th>Owner</th>
                    <th>LastChange</th>
                    <th>Shorthescription</th>
                    <th>SLAKunde</th>
                </tr>
                <tr>
                    <td>Close</td>
                    <td>Z_INC02694200A</td>
                    <td>answered</td>
                    <td>soa.vtis</td>
                    <td>VISSERVDSK</td>
                    <td>2</td>
                    <td>Saburi</td>
                    <td>2023-08-18 09:16:23</td>
                    <td>VFPDB Link Not Accessible from  NPSADM@NPSDB</td>
                    <td>2023-08-17 17:57:45</td>

                </tr>
                <tr>
                    <td>Close</td>
                    <td>Z_INC02694200A</td>
                    <td>answered</td>
                    <td>soa.vtis</td>
                    <td>VISSERVDSK</td>
                    <td>2</td>
                    <td>Saburi</td>
                    <td>2023-08-18 09:16:23</td>
                    <td>VFPDB Link Not Accessible from  NPSADM@NPSDB</td>
                    <td>2023-08-17 17:57:45</td>

                </tr>
                <tr>
                    <td>Close</td>
                    <td>Z_INC02694200A</td>
                    <td>answered</td>
                    <td>soa.vtis</td>
                    <td>VISSERVDSK</td>
                    <td>2</td>
                    <td>Saburi</td>
                    <td>2023-08-18 09:16:23</td>
                    <td>VFPDB Link Not Accessible from  NPSADM@NPSDB</td>
                    <td>2023-08-17 17:57:45</td>

                </tr>
                <tr>
                    <td>Close</td>
                    <td>Z_INC02694200A</td>
                    <td>answered</td>
                    <td>soa.vtis</td>
                    <td>VISSERVDSK</td>
                    <td>2</td>
                    <td>Saburi</td>
                    <td>2023-08-18 09:16:23</td>
                    <td>VFPDB Link Not Accessible from  NPSADM@NPSDB</td>
                    <td>2023-08-17 17:57:45</td>
                </tr>
            </table>
    </div>

    <div class="service-request">
            <div class="text-center table-heading">
             460 open Service Request
            </div>
            <table class="table table-striped table-hover">
                <tr>
                    <th>ToDo</th>
                    <th>AT Number</th>
                    <th>State</th>
                    <th>User</th>
                    <th>Team</th>
                    <th>Priority</th>
                    <th>Owner</th>
                    <th>LastChange</th>
                    <th>Shorthescription</th>
                    <th>SLAKunde</th>
                </tr>
                <tr>
                    <td>yes</td>
                    <td>Z_SRT02324267A</td>
                    <td>Assigned</td>
                    <td>raj.shah1</td>
                    <td>ORCL_APP</td>
                    <td>4</td>
                    <td>Hajek</td>
                    <td>2023-08-18 09:16:23</td>
                    <td>Create Profile "OPM_gui_user" in opmfprd</td>
                    <td>2023-08-17 17:57:45</td>
                </tr>
                <tr>
                    <td>yes</td>
                    <td>Z_SRT02324267A</td>
                    <td>Assigned</td>
                    <td>raj.shah1</td>
                    <td>ORCL_APP</td>
                    <td>4</td>
                    <td>Hajek</td>
                    <td>2023-08-18 09:16:23</td>
                    <td>Create Profile "OPM_gui_user" in opmfprd</td>
                    <td>2023-08-17 17:57:45</td>
                </tr>
                <tr>
                    <td>yes</td>
                    <td>Z_SRT02324267A</td>
                    <td>Assigned</td>
                    <td>raj.shah1</td>
                    <td>ORCL_APP</td>
                    <td>4</td>
                    <td>Hajek</td>
                    <td>2023-08-18 09:16:23</td>
                    <td>Create Profile "OPM_gui_user" in opmfprd</td>
                    <td>2023-08-17 17:57:45</td>
                </tr>
                <tr>
                    <td>yes</td>
                    <td>Z_SRT02324267A</td>
                    <td>Assigned</td>
                    <td>raj.shah1</td>
                    <td>ORCL_APP</td>
                    <td>4</td>
                    <td>Hajek</td>
                    <td>2023-08-18 09:16:23</td>
                    <td>Create Profile "OPM_gui_user" in opmfprd</td>
                    <td>2023-08-17 17:57:45</td>
                </tr>
            </table>
    </div>

    <div class="password-check">
        <div class="text-center table-heading">
            Password Check from  18.08.2023 11:26:46 found Errors
        </div>
        <p>checks OK :3929 <br> checks Failed:163</p>
        <table class="table table-responsive table-striped table-hover">
            <thead>
                <tr>
                     <th>Error</th>
                     <th>Count</th>
                </tr>
            <thead>
            <tr>
                <td>Connect Timeout</td>
                <td>18</td>
            </tr>
            <tr>
                <td>ORA-01017: invalid Username/password; logon denied</td>
                <td>18</td>
            </tr>
        </table>
    </div>
    </div>
   

@extends('Admin.includes.footer')


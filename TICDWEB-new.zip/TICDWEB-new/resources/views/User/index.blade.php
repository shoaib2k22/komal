<?php

// define('TITLE', 'User Login');
// define('PAGE', 'userLogin');

// include('controller/login.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>User Login</title>
  <link rel="shortcut icon" type="image/x-icon" href="../img/logo.png">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="{{asset('assets/login/css/bootstrap.min.css')}}">
  <!-- Font Awesome CSS -->
  <link rel="stylesheet" href="{{asset('assets/login/css/all.min.css')}}">

  <style>
    .custom-margin {
         margin-top: 8vh;
      }
	 .img{
	  background: url('../img/4.png')no-repeat;
	  width: 100%;
	  height: 100vh;
	  margin: 0% auto;
	  background-size: cover;
	  background-position: center;
	  position: relative;
	}
	.img::before{
	  content: '';
	  position: absolute;
	  height: 100%;
	  width: 100%;
	  background: rgba(0, 0, 0, 0.4);
	}
	.center{
	  position: absolute;
	  top: 52%;
	  left: 50%;
	  transform: translate(-50%, -50%);
	  width: 100%;
	  padding: 0 20px;
	}
	.shadow-lg{
		background: #fff;
		border-radius:5px;
	}
	.form-group {
		margin-bottom: 2rem;
	}
   </style>
</head>

<body>
  <div class="img"></div>
  <div class="center">
   <div class="container-fluid mb-5">
    <div class="row justify-content-center">
      <div class="col-sm-6 col-md-4">
        <form action="" class="shadow-lg p-4" method="POST">
          <p class="text-center" style="font-size: 20px; margin-top: 5%;"> 
		    <i class="fas fa-user-secret text-danger"></i> 
			<span>User Login</span>
		  </p>
		  <div class="form-group">
            <i class="fas fa-user"></i><label for="email" class="pl-2 font-weight-bold">Email</label><input type="email"
              class="form-control" placeholder="e.g john@vodafone.com" name="uEmail">
          </div>
          
		  <div class="form-group">
            <i class="fas fa-key"></i><label for="pass" class="pl-2 font-weight-bold">Password</label><input type="password"
              class="form-control" placeholder="Password" name="uPassword">
          </div>
		  
		  <div class="form-group row">
			<div class="col-md-12">
				<div class="custom-control custom-checkbox">
					<input type="checkbox" class="custom-control-input remember_me" name="remember_me" id="customCheck1">
					<label class="custom-control-label" for="customCheck1"><span>Remember me</span></label>
					<!--<a href="javascript:void(0)" id="to-recover" class="text-dark float-right"><i class="fa fa-lock m-r-5"></i> Forgot password?</a>-->
				</div>
			</div>
		  </div>
		  
          <button type="submit" class="btn btn-outline-danger mt-3 btn-block shadow-sm font-weight-bold">Login</button>
          <?php if(isset($msg)) {echo $msg; } ?>
        </form>
      </div>
    </div>
  </div>
 </div>

  <!-- Boostrap JavaScript -->
  <script src="{{url('../assets/login/js/jquery.min.js')}}"></script>
  <script src="{{url('../assets/login/js/popper.min.js')}}"></script>
  <script src="{{url('../assets/login/js/bootstrap.min.js')}}"></script>
  <script src="{{url('../assets/login/js/all.min.js')}}"></script>
</body>

</html>
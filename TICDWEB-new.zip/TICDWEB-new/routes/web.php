<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AdbmController;
use App\Http\Controllers\AdministrationController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [HomeController::class, 'index']);
Route::get('homepage', [AdbmController::class, 'homepage']);
// Route::post('login', [HomeController::class, 'index']);

// Route::get('/', function(){
//     return view('Admin/index');
// });
Route::get('/user',[HomeController::class,'user']);
// Route::get('User/',function(){
//     return view('User/index');
// });

Route::get('user-dashboard',function(){
    return view('User/dashboard');
});

Route::get('admin-dashboard',function(){
    return view('Admin/dashboard');
});

// ----------------- ADBM Team Route -------------

Route::get('tasks',[AdbmController::class,'tasks']);

Route::get('homepage',[AdbmController::class,'homepage']);
// ----------------- ADBM Team Route End -------------

Route::get('dbi-home',[HomeController::class,'dbi_home']);

Route::get('change-role',[HomeController::class,'change_role']);

Route::get('search-dbi',[HomeController::class,'search_dbi']);

Route::get('list-dbi',[HomeController::class,'list_dbi']);

Route::get('new-dbi',[HomeController::class,'new_dbi']);

Route::get('edit-dbi',[HomeController::class,'edit_dbi']);

Route::get('documentation',[HomeController::class,'documentation']);

Route::get('cleanup',[HomeController::class,'cleanup']);

Route::get('show-dbi-source-code',[HomeController::class,'show_dbi_source_code']);

Route::get('show-summery',function(){
    return view('admin/show-summery');
});

// ADBM Team Tab Route

// ----------------- Administration Page Start -------------
Route::get('register-user',[AdministrationController::class,'register_user']);

Route::get('user-search',[AdministrationController::class,'user_search']);

Route::get('user-edit',[AdministrationController::class,'user_edit']);

Route::get('user-list',[AdministrationController::class,'user_list']);

Route::get('edit-roles',[AdministrationController::class,'edit_roles']);

Route::get('edit-rights',[AdministrationController::class,'edit_rights']);

Route::get('main-menu',[AdministrationController::class,'main_menu']);

Route::get('submenu',[AdministrationController::class,'submenu']);

Route::get('rights',[AdministrationController::class,'rights']);

Route::get('roles',[AdministrationController::class,'roles']);

Route::get('pw-users',[AdministrationController::class,'pw_users']);

Route::get('pw-connects',[AdministrationController::class,'pw_connects']);

Route::get('pw-roles',[AdministrationController::class,'pw_roles']);

Route::get('pw-role-dependencies',[AdministrationController::class,'pw_role_dependencies']);

Route::get('pw-groups',[AdministrationController::class,'pw_groups']);

Route::get('pwservice-password',[AdministrationController::class,'pwservice_password']);

Route::get('change-password',[AdministrationController::class,'change_password']);

Route::get('pw-user-edit',[AdministrationController::class,'pw_user_edit']);

// ----------------- Administration Page End -------------
<?php
$table_name = "server_owners";
$alert = "";

include('controller/select.php');
include("includes/header.php");

	$sql_show_hide = "SELECT * FROM show_hide_columns WHERE table_name = 'server_users'";
	$result_show_hide = $conn->query($sql_show_hide);
	$row_show_hide = mysqli_fetch_array($result_show_hide);
	
	
	$arr = [];
	
	for($i=0; $i<=11; $i++){
		$value = $row_show_hide['column_'.$i];
		
		if(!$value){
			array_push($arr,$i);
		}
	}
	
	$column = array('serialize_#', 'server_owner', 'server_user', 'server_name', 'market', 'last_password_changed', 'period', 'created_on', 'status', 'actions');

?>


<div class="page-wrapper">
	<div class="content container-fluid">
	   
	   <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor"><?= $_SESSION['aMarket'] == 1 ? 'DB Users' : 'Server Users'; ?></h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item"><?= $_SESSION['aMarket'] == 1 ? 'DB Users' : 'Server Users'; ?></li>
					</ol>
					<button class="btn btn-danger float-right veiwbutton ml-3" onclick="AddOrDeleteServerUserForm('ServerUser')">Add / Remove User</button>
					<button class="btn btn-primary float-right veiwbutton ml-3" onclick="seheduleJob();">Schedule Job</button>
					<a class="cursor-pointer float-right ml-3" data-toggle="modal" data-target="#selectColumn"><i class="fa fa-columns"></i></a>
				</div>
			</div>
		</div>
	
		<div class="page-header">
			<div class="row">
			  <div class="col-12">
				<?php echo $alert; ?>
			  </div>
			</div>
			
			<div class="row">
			   <div class="col-sm-12">
				  <div class="card card-table">
					<div class="card-body booking_card">
						<div class="table-responsive">
						   <table class="datatable table table-stripped table table-hover table-center mb-0">
						        <thead>
								    <tr>
										<th>#</th>
										<th>Server Owner</th>
										<th>Server User</th>
										<th>Server Name</th>
										<th>Market</th>
										<th>Last Password Changed</th>
										<th>Period</th>
										<th>Created On</th>
										<th>Status</th>
										<!--<th>View</th>-->
										<th class="text-right">Actions</th>
									</tr>
								</thead>
								<tbody>
								 <?php
								  foreach( $result as $key=>$row ){ ?>
									<tr>
										<td><?=++$key?></td>
										<td>
										   <h6 class="text-capitalize font-weight-light m-0"><?=$row["f_name"]." ".$row["l_name"]?></h6>
										   <?=$row["email"];?>
										</td>
										<td class="text-lowercase"><?=$row["user"]?></td>
										<td class="text-lowercase"><?=$row["host_name"]?></td>
										<td class="text-capitalize"><?=$row["market"]?></td>
										<!--
										<td>
										   <button type="submit" class="btn btn-status <?php echo $row["status"] == 1 ? 'btn-success' : 'btn-secondary' ?>" onclick="updateStatusOnDB('<?=$row["id"]?>','dO','<?=$row["status"]?>')">
											   <?php echo $row["status"] == 1 ? 'Active' : 'Inactive' ?>
										   </button>
										</td>
										-->
										<td class="text-center">
										  <?php
										    if($row["last_password_changed"] == null){
												echo "----";
											}
											else{
												echo date('d-M-Y', strtotime($row["last_password_changed"]));
											}
										  ?>
										</td>
										
										
										<td class="text-center"><?php echo isset($row["password_rotation_period"]) ? $row["password_rotation_period"]." Days" : '----'; ?></td>
										
										<td><?=date('d-M-Y', strtotime($row["created_at"]))?></td>
										
										<td class="text-center">
										 <?php 
										   if($row["status"] == 0) 
											     echo '<button class="btn btn-warning btn-status">Pending</button>';
										   
										   if($row["status"] == 1) 
											     echo '<button class="btn btn-success btn-status">Active</button>';
										   
										   if($row["status"] == 2) 
											     echo '<button class="btn btn-danger btn-status">Declined</button>';
										 ?>
									    </td>
										
										<!--
										<td>
											<button class="btn btn-warning" onclick="getServer('<?=$row["id"]?>', '<?=$row["owner"]?>')"><i class="fa fa-eye"></i></button>
										</td>
										-->
										
										<td class="text-right">
											<div class="dropdown dropdown-action d-inline">
											  <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											   <i class="fa fa-th-list ellipse_color"></i>
											  </a>
											  
											  <div class="dropdown-menu dropdown-menu-right">
												  
												  <button class="dropdown-item" onclick="editForm('<?=$row["id"]?>','dO')">
													<i class="fa fa-pencil-square-o m-r-5 text-primary"></i> Edit User 
												  </button>
												  
												  <button class="dropdown-item" data-toggle="modal" data-target="#delete_asset" onclick="deleteOnDB('<?=$row["id"]?>','<?=$row["user"]?>','dSU')">
												   <i class="fa fa-trash-o m-r-5 text-danger"></i> Delete User
												  </button>
											   </div>
											  </div>
										 </td>
									 </tr>
								   <?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			 </div>
		  </div>
	   </div>
    </div>
</div>
	
	
<!-- Modal's -->
 <div id="getServerModal"></div>
 <div id="getFormModal"></div>
 <div id="getStatusModal"></div>
<!-- Model's -->




<div class="modal fade delete-modal" id="selectColumn" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

			<!-- Modal Header -->
			<div class="modal-header">
				<h4 class="modal-title">Column Selection</h4>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>

            <!-- Modal body -->
			<div class="modal-body" style="height: 66vh;overflow-y: auto;">
			    <form id="show_hide_column">
					<div class="row formtype">
						<?php for($k=0; $k<sizeof($column); $k++){?>
							<div class="col-md-12">
								<div class="form-group toggle-group-custom">
									<span class="text-capitalize"><?php echo str_replace('_', ' ', $column[$k]); ?></span>
									<input type="checkbox" name="<?php echo $column[$k]; ?>" data-toggle="toggle" data-style="slow" value="<?php echo $row_show_hide['column_'.$k]; ?>" <?php if($row_show_hide['column_'.$k]){echo "checked";} ?>>
								</div>
							</div>
						<?php } ?>
					</div>
				</form>
			</div>
			
		    <!-- Modal footer -->
			<div class="modal-footer float-right">
				  <button type="button" class="btn btn-danger" onclick="show_hide('ServerUsers')">Save Changes</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			</div>
						
		</div>
		 
	</div>
</div>
	 
	
	
<!-- jQuery -->
<script>
	var element = document.getElementById("ServerUser");
	   element.classList.add("active");
</script>


<?php include("includes/footer.php"); ?>


	
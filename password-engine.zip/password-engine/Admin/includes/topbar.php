<!-- Header -->
<style>
header{
	width:100%;
	height:62px;
	background:rgba(5, 5, 5, 100%);
	border-bottom: 2px solid #5d4b4bd6;
}

header ul{
	display: flex;
	justify-content: space-between;
	list-style: none;
	color: #fff;
	font-family: vodafone Rg;
	font-size: 32px;
	line-height: 20px;
	padding: 0;
	margin-top: 20px;
	font-palette: normal;
}
.header .container-fluid{
	padding: 0px 50px;
}
.header .vois{
   letter-spacing: 5px;
}
.header .vo{
	color: #929292;
	font-weight: 100;
}
.header .is{
	font-weight: bold;
}

.header {
    left: 0;
    position: fixed;
    right: 0px;
    top: 0;
    z-index: 1001;
    height: 65px;
    background-color: #000;
    padding: 0 10px 0 0;
    border-bottom: 1px solid #e6010100;
    box-shadow: 0px 2px 8px 1px #887b7b6e;
    display: flex;
    justify-content: space-between;
	align-items: center;
    padding: 0px 20px;
}	

.vois.logoclass.text{
	font-size: 2rem;
    font-weight: 300;
    background-clip: text;
    -webkit-background-clip: text;
    color: transparent;
    -webkit-text-stroke-width: 1px;
    -webkit-text-stroke-color: #f4f0f0;
    background-image: url(img/4.png);
}

</style>


		<div class="header">
		    <span class="vois logoclass"> <span class="vo">_VO</span><span class="is">IS</span> </span> 
			<span class="vois logoclass"> Password Engine </span> 
			
			<!--
				<a href="javascript:void(0);" id="toggle_btn">
					<i class="fa fa-caret-square-o-left"></i>
				</a>
			-->




			<!-- Mobile Menu Toggle -->
			<a class="mobile_btn" id="mobile_btn">
				<i class="fa fa-bars"></i>
			</a>
			<!-- /Mobile Menu Toggle -->

			
			<!-- Header Right Menu -->
			<ul class="nav user-menu">
				
				<!-- Notifications -->
                <li class="nav-item dropdown noti-dropdown">
					<a href="#" class="dropdown-toggle nav-link pl-0" data-toggle="dropdown">
						<i class="fe fe-bell top-admin"></i> <span class="badge badge-pill">3</span>
					</a>
					<div class="dropdown-menu notifications">
						<div class="topnav-dropdown-header">
							<span class="notification-title">Notifications</span>
							<a href="javascript:void(0)" class="clear-noti"> Clear All </a>
						</div>
						
						<div class="topnav-dropdown-footer">
							<a href="#">View all Notifications</a>
						</div>
					</div>
				</li>
				<!-- /Notifications -->

				<!-- User Menu -->
				<li class="nav-item dropdown has-arrow">
					<a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
						<i class="fa fa-user-o top-admin"></i>
						<span class="top-admin"><?php echo $admin;?></span>
					</a>
					
					<div class="dropdown-menu">
						<div class="user-header">
							<div class="avatar avatar-sm">
								<i class="fa fa-user-o"></i>
							</div>
							<div class="user-text">
								<h6>Admin</h6>
								<p class="text-muted mb-0">Administrator</p>
							</div>
						</div>
						<a class="dropdown-item" href="profile.php">My Profile</a>
						<a class="dropdown-item" href="#settings.html">Account Settings</a>
						<a class="dropdown-item" href="../logout.php?key=0">Logout</a>
					</div>
				</li>
				<!-- /User Menu -->
				
				

			</ul>
			<!-- /Header Right Menu -->

		</div>
		<!-- /Header -->
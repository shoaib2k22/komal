<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<title>Vodafone Password Engine</title>

	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="../img/logo.png">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">

	<!-- Fontawesome CSS -->
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/plugins/datatables/datatables.min.css">
	<!-- Feathericon CSS -->
	<link rel="stylesheet" href="assets/css/feathericon.min.css">

	<link rel="stylesheet" href="assets/plugins/morris/morris.css">

	<!-- Main CSS -->
	<link rel="stylesheet" href="assets/css/style.css">
	
	<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet"/>
	
	<style>
	.select2-container {
		box-sizing: border-box;
		display: block;
		margin: 0;
		position: relative;
		vertical-align: middle;
		width:100% !important;
	}
	
	.select2-container--default .select2-selection--single .select2-selection__clear {
		cursor: pointer;
		float: right;
		font-weight: bold;
		display: none;
	}
	
	.select2-container--default .select2-selection--single .select2-selection__placeholder {
		color: #333;
		font-size: 15px;
	}

    .select2-container--default .select2-selection--single {
		background-color: #fff;
		background-clip: padding-box;
		border: 1px solid #ced4da;
		border-radius: 0.25rem;
	}
	
	.select2-container .select2-selection--single {
		height: 40px;
	}
	
	.select2-container--default .select2-selection--single .select2-selection__rendered {
		color: #444;
		line-height: 40px;
	}
	
	.select2-container--default .select2-selection--single .select2-selection__arrow {
		height: 40px;
	}
	
	.select2-container .select2-selection--single .select2-selection__rendered {
		padding: 0rem 0.75rem;
	}
	
    @media (min-width: 992px){
		.modal-sh{
			max-width: 950px;
		}
	}
	 
	.dataTables_length select, .dataTables_filter input {
		border: 0;
		border-bottom:1px solid #e0e0e0;
		border-radius:0;
	}
	
	.dataTables_length select:focus, .dataTables_filter input:focus {
		outline: none;
		border-bottom:1px solid #fb9678;
		transition-duration: 0.3s;
	}
	.btn-status{
		padding: 0rem 1rem;
		font-weight:100;
	}
	#delete_asset form{
		display:inline-block;
	}
	.form-group {
		margin-bottom: 0rem;
		margin-top: 1rem;
    }
	.modal-body {
		padding: 1rem 2rem;
	}
	
	.sidebar-txt{
		padding:0px;
		font-size:11px;
		margin: 0;
		padding-bottom: 10px;
		/*color: #6c757d;*/
        font-weight: 400;
	}
	.mini-sidebar .sidebar-menu > ul > li > a {
		padding: 0px;
		padding-top: 5px;
	}
	.sidebar-menu {
		padding: 0px 0 0 1px;
	}
	
	.sidebar-menu ul {
		font-size: 15px;
		list-style-type: none;
		padding: 0;
		position: relative;
		margin-right: 0px;
	}
	
	
	.list-divider {
		border-bottom: 1px solid #edf2f9;
		height: 0px !important;
	}
	
	.sidebar {
		background-color: #fff;
		bottom: 0;
		left: 0;
		margin-top: 0;
		position: fixed;
		top: 66px;
		transition: all 0.2s ease-in-out 0s;
		width: 78px;
		z-index: 1001;
	}
	
	.page-wrapper {
		margin-left: 80px;
		padding-top: 32px;
		position: relative;
		transition: all 0.4s ease;
		background-color: #f2f5fa;
	}
	
	.header .header-left {
		float: left;
		height: 65px;
		padding: 0 0px;
		position: relative;
		text-align: center;
		width: 78px;
		background-color: #000;
	}
	
	.submenu_class {
		border-left: 1px solid #dfdfdf;
		position: relative;
		margin-left: 0px;
	}
	
	.sidebar-menu ul ul a {
		display: block;
		font-size: 14px;
		padding: 10px 0px 10px 0px;
		position: relative;
		border-top: 1px solid #f0eded;
	}
	
	
	.sidebar-menu ul ul a:before {
		display:none;
	}
	

	
	.sidebar-menu ul ul a {
		display: block;
		font-size: 14px;
		padding: 10px 0px 0px 0px;
		position: relative;
		border-top: 1px solid #f0eded;
	}
	
	.header {
		left: 0;
		position: fixed;
		right: 0;
		top: 0;
		z-index: 1001;
		height: 65px;
		background-color: #000;
		padding: 0 10px 0 0;
		border-bottom: 1px solid #e6010100;
		box-shadow: 0px 2px 8px 1px #887b7b6e;
	}
	
	.user-menu {
		float: right;
		margin: 0px;
		position: relative;
		z-index: 99;
		color: #ffffff;
	}
	
	.user-menu.nav > li > a {
		color: #fff;
	}
	

	
	.header .has-arrow .dropdown-toggle:after {
		border-bottom: 2px solid #fff;
		border-right: 2px solid #fff;
	}
	
	
	.page-titles {
		background: #dddddd;
		padding: 0px 0px;
		line-height: 2rem;
		padding-right: 15px;
		left: 94px;
		position: fixed;
		right: 16px;
		top: 65px;
		z-index: 100;
	}
	
	.page-wrapper > .content {
		padding: 0rem 1.5rem 0;
		padding-bottom: 0.5rem;
		padding-top: 7rem;
	}
	
	.breadcrumb {
		display: -ms-flexbox;
		display: flex;
		-ms-flex-wrap: wrap;
		flex-wrap: wrap;
		padding: 0.75rem 0rem;
		margin-bottom: 0rem;
		list-style: none;
		background-color: #e9ecef00;
		border-radius: 0rem;
		font-size: 15px;
	}
	
	.text-themecolor{
		font-size: 22px;
		margin: 0 !important;
		color:#000;
	}
	
	.breadcrumb-item+.breadcrumb-item {
		padding-left: 0.5rem;
		color: #e60101;
	}
	
	.slimScrollBar{
		background: rgb(97 89 89) !important;
        width: 4px !important;
	}
	
	.form-control-error{
		font-size:12px;
		text-align:start;
		font-weight:400;
		color:#e84646 !important;
	}
	
	.top-admin{
		line-height: 60px;
		color: #fff !important;
		font-size: 18px;
	}
	
	.pl-0{
		padding-left: 0 !important;
	}
	
	#addServer{
		display:none;
	}
	
	.h6, h6, .btn, body {
		font-size: 0.8rem;
	}

	.header {
	   background-color: #000000 !importanr;
	}
	
	.table {
		color: #000;
		font-size: 14px;
		border-collapse: separate !important;
		border-spacing:10px 0px !important;
	}
	
	th{
		cursor: pointer;
		background-image: linear-gradient(-216deg, #edeaeaa6 63%, #fff9f9);
		border-radius: 3px;
		border: 2px solid #ccc4c400;
		box-shadow: 2px 2px 2px 1px #a19d9dc2;
	}
	
	
	@media only screen and (max-width: 991.98px){
		.page-wrapper {
			margin-left: 0 !important;
			padding-left: 0;
			padding-right: 0;
			-webkit-transition: all 0.4s ease;
			-moz-transition: all 0.4s ease;
			transition: all 0.4s ease;
		}
	}
	
	
	/* width */
	::-webkit-scrollbar {
	  width: 10px;
	  height:10px;
	}
	
	::-webkit-scrollbar-button {
		height: 1px;
	}

	/* Track */
	::-webkit-scrollbar-track {
	  background: #f1f1f1; 
	}
	 
	/* Handle */
	::-webkit-scrollbar-thumb {
	  background: #888; 
	}

	/* Handle on hover */
	::-webkit-scrollbar-thumb:hover {
	  background: #555; 
	}
	
	
	#loaderImg{
		position: absolute;
		bottom: 50%;
		left: 50%;
		transform: translate(-25%, 35%);
		z-index: 99999;
		display:none;
	}
	#loaderImg img{
	   width:50%;
	}
	
	.sidebar {
		 top: 65px;
		 background: linear-gradient(270deg,#e60000 10%,#900);
		 background: #cb0505eb;
	}
	
	.sidebar-txt, .sidebar-menu ul li a i {
      color: #fff;
    }
	
	#sidebar-menu ul .active {
		color: #ffffff !important;
		border-left: 7px solid #ffffff;
		margin-right: 7px !important;
	}
	
	.sidebar-txt {
		padding-bottom: 5px;
	}
	
	.sidebar-menu ul li a i{
		transition: transform .2s;
		text-align: center;
		
	}
	
	#sidebar-menu ul li{
		transition: transform .2s;
		text-align: center;
		padding-top: 8px;
		padding-bottom: 8px;
	}
	
	#sidebar-menu ul li:first-child{
		padding-top: 20px;
	}
	
	#sidebar-menu ul li:hover{
		transform:scale(1.2);
	}
	#sidebar-menu ul .active{
		transform:scale(1.2);
	}
	.h1, .h2, .h3, .h4, .h5, .h6, h1, h2, h3, h4, h5, h6 {
		margin-bottom: 0.5rem;
		font-weight: 200;
		line-height: 1.2;
	}
	table th:hover{
		color: #e84646;
		transform: scaleY(1);
	}
	
	
	.table th{
		color: #000000;
		font-size: 14px;
		
	}
	
	table .sorting_asc{
		color: #e84646;
	}
	
	.modal-header {
		background: #dddddd94;
	}
	select[name="server"], select[name="sourceServer"], select[name="sourceUser"], select[name="targetServer"], select[name="targetUser"]{
	   text-transform: lowercase !important;
	}
	
	
	
	</style>
	
	<style>
#selectColumn .table td, #selectColumn .table th {
    padding: 0.5rem;
    vertical-align: middle;
    border-top: 1px solid #dee2e6;
}

.toggle-group-custom{
	border: 1px solid #d3caca94;
	display:flex;
    justify-content: space-between;
    padding: 5px 8px;
    border-radius: 3px;
    line-height: 33px;
    font-size: 16px;
}

.btn-group-xs>.btn,.btn-xs{padding:.35rem .4rem .25rem .4rem;font-size:.875rem;line-height:.5;border-radius:.2rem}.checkbox label .toggle,.checkbox-inline .toggle{margin-left:-1.25rem;margin-right:.35rem}.toggle{position:relative;overflow:hidden}.toggle.btn.btn-light,.toggle.btn.btn-outline-light{border-color:rgba(0,0,0,.15)}.toggle input[type=checkbox]{display:none}.toggle-group{position:absolute;width:200%;top:0;bottom:0;left:0;transition:left .35s;-webkit-transition:left .35s;-moz-user-select:none;-webkit-user-select:none}.toggle-group label,.toggle-group span{cursor:pointer}.toggle.off .toggle-group{left:-100%}.toggle-on{position:absolute;top:0;bottom:0;left:0;right:50%;margin:0;border:0;border-radius:0}.toggle-off{position:absolute;top:0;bottom:0;left:50%;right:0;margin:0;border:0;border-radius:0;box-shadow:none}.toggle-handle{position:relative;margin:0 auto;padding-top:0;padding-bottom:0;height:100%;width:0;border-width:0 1px;background-color:#fff}.toggle.btn-outline-primary .toggle-handle{background-color:var(--primary);border-color:var(--primary)}.toggle.btn-outline-secondary .toggle-handle{background-color:var(--secondary);border-color:var(--secondary)}.toggle.btn-outline-success .toggle-handle{background-color:var(--success);border-color:var(--success)}.toggle.btn-outline-danger .toggle-handle{background-color:var(--danger);border-color:var(--danger)}.toggle.btn-outline-warning .toggle-handle{background-color:var(--warning);border-color:var(--warning)}.toggle.btn-outline-info .toggle-handle{background-color:var(--info);border-color:var(--info)}.toggle.btn-outline-light .toggle-handle{background-color:var(--light);border-color:var(--light)}.toggle.btn-outline-dark .toggle-handle{background-color:var(--dark);border-color:var(--dark)}.toggle[class*=btn-outline]:hover .toggle-handle{background-color:var(--light);opacity:.5}.toggle.btn{min-width:3.7rem;min-height:2.15rem}.toggle-on.btn{padding-right:1.5rem}.toggle-off.btn{padding-left:1.5rem}.toggle.btn-lg{min-width:5rem;min-height:2.815rem}.toggle-on.btn-lg{padding-right:2rem}.toggle-off.btn-lg{padding-left:2rem}.toggle-handle.btn-lg{width:2.5rem}.toggle.btn-sm{min-width:3.125rem;min-height:1.938rem}.toggle-on.btn-sm{padding-right:1rem}.toggle-off.btn-sm{padding-left:1rem}.toggle.btn-xs{min-width:2.19rem;min-height:1.375rem}.toggle-on.btn-xs{padding-right:.8rem}.toggle-off.btn-xs{padding-left:.8rem}
</style>

</head>

<body>
	<!-- Main Wrapper -->
	<div class="main-wrapper">
	
	   <?php include("includes/topbar.php"); ?>
	   
		<?php include("includes/sidebar.php"); ?>
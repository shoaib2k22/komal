<?php
include('../../dbConnection.php');


if($_REQUEST['key']=='ServerUsers'){
	$table_name = "server_users";
	$column_0 = $_REQUEST['serialize_#'] ?? 0;
	$column_1 = $_REQUEST['server_owner'] ?? 0;
	$column_2 = $_REQUEST['server_user'] ?? 0;
	$column_3 = $_REQUEST['server_name'] ?? 0;
	$column_4 = $_REQUEST['market'] ?? 0;
	$column_5 = $_REQUEST['last_password_changed'] ?? 0;
	$column_6 = $_REQUEST['period'] ?? 0;
	$column_7 = $_REQUEST['created_on'] ?? 0;
	$column_8 = $_REQUEST['status'] ?? 0;
	$column_9 = $_REQUEST['actions'] ?? 0;
	$column_10 = $_REQUEST['default'] ?? 0;
}

if($_REQUEST['key']=='Users'){
	$table_name = "users";
	$column_0 = $_REQUEST['serialize_#'] ?? 0;
	$column_1 = $_REQUEST['name'] ?? 0;
	$column_2 = $_REQUEST['unix_id'] ?? 0;
	$column_3 = $_REQUEST['market'] ?? 0;
	$column_4 = $_REQUEST['created_on'] ?? 0;
	$column_5 = $_REQUEST['assigned'] ?? 0;
	$column_6 = $_REQUEST['type'] ?? 0;
	$column_7 = $_REQUEST['status'] ?? 0;
	$column_8 = $_REQUEST['actions'] ?? 0;
	$column_9 = $_REQUEST['default'] ?? 0;
	$column_10 = $_REQUEST['default'] ?? 0;
}

if($_REQUEST['key']=='Roles'){
	$table_name = "roles";
	$column_0 = $_REQUEST['serialize_#'] ?? 0;
	$column_1 = $_REQUEST['role'] ?? 0;
	$column_2 = $_REQUEST['market'] ?? 0;
	$column_3 = $_REQUEST['created_on'] ?? 0;
	$column_4 = $_REQUEST['server_list'] ?? 0;
	$column_5 = $_REQUEST['status'] ?? 0;
	$column_6 = $_REQUEST['actions'] ?? 0;
	$column_7 = $_REQUEST['default'] ?? 0;
	$column_8 = $_REQUEST['default'] ?? 0;
	$column_9 = $_REQUEST['default'] ?? 0;
	$column_10 = $_REQUEST['default'] ?? 0;
}


if($_REQUEST['key']=='Servers'){
	$table_name = "servers";
	$column_0 = $_REQUEST['serialize_#'] ?? 0;
	$column_1 = $_REQUEST['owner'] ?? 0;
	$column_2 = $_REQUEST['server_name'] ?? 0;
	$column_3 = $_REQUEST['IP_address'] ?? 0;
	$column_4 = $_REQUEST['market'] ?? 0;
	$column_5 = $_REQUEST['created_on'] ?? 0;
	$column_6 = $_REQUEST['users'] ?? 0;
	$column_7 = $_REQUEST['status'] ?? 0;
	$column_8 = $_REQUEST['actions'] ?? 0;
	$column_9 = $_REQUEST['default'] ?? 0;
	$column_10 = $_REQUEST['default'] ?? 0;
}


if($_REQUEST['key']=='PasswordEncryption'){
	$table_name = "password_encryption";
	$column_0 = $_REQUEST['serialize_#'] ?? 0;
	$column_1 = $_REQUEST['source_server'] ?? 0;
	$column_2 = $_REQUEST['source_IP'] ?? 0;
	$column_3 = $_REQUEST['source_user'] ?? 0;
	$column_4 = $_REQUEST['source_account'] ?? 0;
	$column_5 = $_REQUEST['target_server'] ?? 0;
	$column_6 = $_REQUEST['target_user'] ?? 0;
	$column_7 = $_REQUEST['created_on'] ?? 0;
	$column_8 = $_REQUEST['keys'] ?? 0;
	$column_9 = $_REQUEST['actions'] ?? 0;
	$column_10 = $_REQUEST['default'] ?? 0;
}

$sql = "UPDATE show_hide_columns SET 
			column_0=  '$column_0', 
			column_1 = '$column_1',
			column_2 = '$column_2',
			column_3 = '$column_3',
			column_4 = '$column_4',
			column_5 = '$column_5',
			column_6 = '$column_6',
			column_7 = '$column_7',
			column_8 = '$column_8',
			column_9 = '$column_9',
			column_10 = '$column_10'
		WHERE table_name = '$table_name'";

if($conn->query($sql) === TRUE) {
	$myObj = new stdClass();
	$myObj->code = 200;
	$myObj->text = "Updated Successfully";
	$myObj->msg = "success";
	$myJSON = json_encode($myObj);
	echo $myJSON;
	die();
	
} else {
	$myObj = new stdClass();
	$myObj->code = 200;
	$myObj->text = "Somthing Went Wrong";
	$myObj->msg = "info";
	$myJSON = json_encode($myObj);
	echo $myJSON;
	//echo "Error: " . $sql . "<br>" . $conn->error;
	die();
}
?>
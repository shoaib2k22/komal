<?php
$table_name = "dashboard";

include('controller/select.php');
include("includes/header.php");

?>

<style>
.box-shadow{
	box-shadow: 1px 1px 4px 0px grey;
}
.card board1::hover{
	scale:1.2;
}
</style>


<style>
body .container-fluid {
  display: flex;
  justify-content: start;
  align-items: center;
  flex-wrap: wrap;
  margin: 0px;
  
}

body .container-fluid .card {
  background: #232427db;
  position: relative;
  min-width: 22%;
  height: 170px;
  box-shadow: inset 5px 5px 5px rgba(0, 0, 0, 0.2),
    inset -5px -5px 15px rgba(255, 255, 255, 0.1),
    5px 5px 15px rgba(0, 0, 0, 0.3), -5px -5px 15px rgba(255, 255, 255, 0.1);
  border-radius: 15px;
  margin: 15px 15px 25px 15px;
  transition: 0.5s;
}

body .container-fluid .card:nth-child(1) .box .content a {
  background: #2196f3;
}

body .container-fluid .card:nth-child(2) .box .content a {
  background: #e91e63;
}

body .container-fluid .card:nth-child(3) .box .content a {
  background: #23c186;
}

body .container-fluid .card .box {
  position: absolute;
  top: 15px;
  bottom: 15px;
  left: 15px;
  right: 15px;
  background: #2a2b2f;
  border-radius: 15px;
  overflow: hidden;
  transition: 0.5s;
  width:91%;
}

body .container-fluid .card .box:hover {
  transform: translateY(-50px);
}

body .container-fluid .card .box:before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 50%;
  height: 100%;
  background: rgba(255, 255, 255, 0.03);
}

body .container-fluid .card .box .content {
  padding: 20px;
  text-align: center;
}

body .container-fluid .card .box .content h2 {
  position: absolute;
  top: 0px;
  right: 30px;
  font-size: 3rem;
  color: rgb(255 255 255 / 38%);
}

body .container-fluid .card .box .content h3 {
  font-size: 1.8rem;
  color: #fff;
  z-index: 1;
  transition: 0.5s;
  margin-bottom: 15px;
  text-align:start;
}

body .container-fluid .card .box .content p {
  font-size: 1rem;
  font-weight: 300;
  color: rgba(255, 255, 255, 0.9);
  z-index: 1;
  transition: 0.5s;
}

body .container-fluid .card .box .content a {
  position: relative;
  display: inline-block;
  padding: 8px 20px;
  border-radius: 5px;
  text-decoration: none;
  color: white;
  margin-top: 20px;
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
  transition: 0.5s;
  width:40%;
}
body .container-fluid .card .box .content a:hover {
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.6);
  background: #fff;
  color: #000;
}

.text-heading{
	color: #ffff !important;
	font-size: 26px !important;
	position: absolute !important;
	bottom: 4rem !important;
	left: 10px !important;
}

.button-heading{
	position: absolute !important;
	left: 10% !important;
	bottom: 12px !important;
}

</style>


<div class="page-wrapper">
    <div class="content container-fluid-fluid">
	
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Dashboard</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center mr-3">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Dashboard</li>
					</ol>
				</div>
			</div>
		</div>
		
		
        <div class="page-header">
			<div class="row">
				<div class="col-sm-12">
				    <h3 class="page-title mt-3">Hi <?php echo $grettings; ?></h3>
					<p class="page-paragraph">Welcome to _VOIS</p>
				</div>
			</div>
		</div>
		
		<!-- /Page Header 
		<div class="row">
			<div class="col-xl-3 col-sm-6 col-12">
				<div class="card board1 fill border-success box-shadow">
					<div class="card-body">
						<div class="dash-widget-header">
							<div>
								<h3 class="card_widget_header text-success"><?=$requested_roles;?></h3>
								<h6 class="text-muted text-success">Request</h6>
							</div>
							<div class="ml-auto mt-md-3 mt-lg-0">
								<span class="opacity-7 text-muted text-success font-size-2rem"><i class="fa fa-paper-plane-o"></i></span>
							</div>
						</div>
					</div>
					<div class="card-footer">
						<a href="all-roles-requests.php"><button type="button" class="btn btn-success btn-block btn-outline">View</button></a>
					</div>
				</div>
			</div>
			
			<div class="col-xl-3 col-sm-6 col-12">
				<div class="card board1 fill border-danger box-shadow">
					<div class="card-body">
						<div class="dash-widget-header">
							<div>
								<h3 class="card_widget_header text-danger"><?=$all_connections;?></h3>
								<h6 class="text-muted text-danger">Connections</h6>
							</div>
							<div class="ml-auto mt-md-3 mt-lg-0">
								<span class="opacity-7 text-muted text-danger font-size-2rem"><i class="fa fa-plug"></i></span>
							</div>
						</div>
                     </div>
					 <div class="card-footer">
						  <a href="all-roles.php"><button type="button" class="btn btn-danger btn-block btn-outline">View</button></a>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-sm-6 col-12">
				<div class="card board1 fill border-primary box-shadow">
					<div class="card-body">
						<div class="dash-widget-header">
							<div>
								<h3 class="card_widget_header text-primary"><?=$all_users;?></h3>
								<h6 class="text-muted text-primary">Users</h6>
							</div>
							<div class="ml-auto mt-md-3 mt-lg-0">
								<span class="opacity-7 text-muted text-primary font-size-2rem"><i class="fa fa-user-o"></i></span>
							</div>
						</div>
					</div>
					<div class="card-footer">
						  <a href="all-users.php"><button type="button" class="btn btn-primary btn-block btn-outline">View</button></a>
					</div>
				</div>
			</div>
			<div class="col-xl-3 col-sm-6 col-12">
				<div class="card board1 fill border-warning box-shadow">
					<div class="card-body">
						<div class="dash-widget-header">
							<div>
								<h3 class="card_widget_header text-warning"><?=$all_roles;?></h3>
								<h6 class="text-muted text-warning">Roles</h6>
							</div>
							<div class="ml-auto mt-md-3 mt-lg-0">
								<span class="opacity-7 text-muted text-warning font-size-2rem"><i class="fa fa-users"></i></span>
							</div>
						</div>
					</div>
					<div class="card-footer">
						<a href="all-roles.php"><button type="button" class="btn btn-warning btn-block btn-outline">View</button></a>
					</div>
				 </div>
			  </div>
			-->  
			  

		<div class="container-fluid">
		  
			  <div class="card">
				<div class="box">
				 <div class="content">
					<h2><?=$requested_roles;?></h2>
					<h3 class="text-heading">Requests</h3>
					<a href="all-roles-requests.php" class="button-heading">View</a>
				  </div>
				</div>
			  </div>
			  
			 <!--
			  <div class="card">
				<div class="box">
				 <div class="content">
					<h2><?=$all_connections;?></h2>
					<h3 class="text-heading">Connections</h3>
					<a href="all-roles.php" class="button-heading btn-danger">View</a>
				  </div>
				</div>
			  </div>
			  -->
		  
			  <div class="card">
				<div class="box">
				 <div class="content">
					<h2><?=$all_users;?></h2>
					<h3 class="text-heading">Users</h3>
					<a href="all-users.php" class="button-heading">View</a>
				  </div>
				</div>
			  </div>
		  
		      <div class="card">
				<div class="box">
				 <div class="content">
					<h2><?=$all_roles;?></h2>
					<h3 class="text-heading">Roles</h3>
					<a href="all-roles.php" class="button-heading btn-secondary">View</a>
				  </div>
				</div>
			  </div>
		  
			  <div class="card">
				<div class="box">
				 <div class="content">
					<h2><?=$all_servers;?></h2>
					<h3 class="text-heading">Servers</h3>
					<a href="all-servers.php" class="button-heading btn-warning">View</a>
				  </div>
				</div>
			  </div>
		  
		<?php if($aRole == 0){?>
		  <div class="card">
			<div class="box">
			 <div class="content">
				<h2><?=$all_admins;?></h2>
				<h3 class="text-heading">Admins</h3>
				<a href="all-admins.php" class="button-heading btn-danger">View</a>
			  </div>
			</div>
		  </div>
		  
		  <div class="card">
			<div class="box">
			 <div class="content">
				<h2><?=$all_markets;?></h2>
				<h3 class="text-heading">Markets</h3>
				<a href="all-markets.php" class="button-heading btn-info">View</a>
			  </div>
			</div>
		  </div>
	   <?php } ?>
		  
		 
		</div>
	 </div>
  </div>
  
	
	
<!-- JQuery -->
<?php include("includes/footer.php"); ?>
<script>
	var element = document.getElementById("dashboard");
	   element.classList.add("active");
</script>

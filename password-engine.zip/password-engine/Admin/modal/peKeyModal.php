<?php

$modalName = "passKey";

include('../controller/modal.php');

$key = $_REQUEST['key'];

$sql_pe = "SELECT encrypt_key from password_encryption WHERE id = $key";
	$result_pe = mysqli_query($conn , $sql_pe);
	$row_pe = mysqli_fetch_assoc($result_pe);
	$encrypted_key = $row_pe['encrypt_key'];

?>


	<div class="modal fade delete-modal" id="getUserPerServer">
	  <div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

		  <!-- Modal Header -->
		  <div class="modal-header">
			<h4 class="modal-title text-capitalize">Password Encryption Key</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>

		  <!-- Modal body -->
		  <div class="modal-body">
			  <div class="row formtype">
				<div class="col-md-12">
				   <div class="form-group">
					  <textarea class="form-control" type="text" id="encrypted_key" rows="5" cols="40"> <?php echo $encrypted_key; ?> </textarea>
					  <!--<a onclick="copy()"><i class="fa fa-clone color-gray"></i></a>-->
				   </div>
				</div>
			  </div>
		  </div>
		  <!-- Modal body end-->
		  
		  <!-- Modal footer -->
		  <div class="modal-footer float-right">
		        <button type="button" class="btn btn-danger" onclick="copyToClipboard('encrypted_key')">Copy</button>
				<button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
		  </div>
		  <!-- Modal footer end-->
		  
		</div>
	   </div>
	 </div>

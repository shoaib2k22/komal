<?php
include('../../dbConnection.php');

$server_id = trim($_POST['server']);

$sSql = "SELECT id, user FROM server_users WHERE server_id = '$server_id'";   
	$sResult = $conn->query($sSql);	

  while($sRow = mysqli_fetch_array($sResult)) { ?> 
	  <option value="<?php echo $sRow['id']; ?>"><?php echo $sRow['user']; ?></option>
<?php } ?>				 
 
<script> 
$(document).ready(function() {
	$('#targetUser').select2({
		placeholder: "Select User",
		allowClear: true
	});
});
</script>
<?php
$table_name = "users";
$alert = "";

include('controller/select.php');
include("includes/header.php");

$sql_show_hide = "SELECT * FROM show_hide_columns WHERE table_name = 'users'";
	$result_show_hide = $conn->query($sql_show_hide);
	$row_show_hide = mysqli_fetch_array($result_show_hide);
	
	
	$arr = [];
	
	for($i=0; $i<=11; $i++){
		$value = $row_show_hide['column_'.$i];
		
		if(!$value){
			array_push($arr,$i);
		}
	}
	
	$column = array('serialize_#', 'name', 'unix_id', 'market', 'created_on', 'assigned', 'type', 'status', 'actions');

?>
<style>
 .table .sorting_disabled {
    color: #4F5467;
    background-color: #e9ecef;
    border-color: #dee2e6;
	text-align:center;
	padding-right: 0.75rem !important;
}
</style>

<div class="page-wrapper">
	<div class="content container-fluid">
	
	    <div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h6 class="text-themecolor">Users</h6>
			</div>
			<div class="col-md-7 align-self-center text-right pr-1">
				<div class="d-flex justify-content-end align-items-center">
					<ol class="breadcrumb">
						<li class="breadcrumb-item">Home</li>
						<li class="breadcrumb-item">Users</li>
					</ol>
					<button class="btn btn-danger float-right veiwbutton ml-3" onclick="getForm('addUser')">
					  <i class="fa fa-plus-circle"></i> Add User
					</button>
					<a class="cursor-pointer float-right ml-3" data-toggle="modal" data-target="#selectColumn"><i class="fa fa-columns"></i></a>
				</div>
			</div>
		</div>
		
		<div class="page-header">
			<div class="row">
			  <div class="col-12">
				<?php echo $alert; ?>
			  </div>
			</div>
			
			<div class="row">
			   <div class="col-sm-12">
				  <div class="card card-table">
					<div class="card-body booking_card">
						<div class="table-responsive">
							<table class="datatable table table-stripped table table-hover table-center mb-0">
							  <thead>
								<tr>
									<th>#</th>
									<th>Name</th>
									<th>Unix Id</th>
									<th>Market</th>
									<th>Created On</th>
									<th>Assigned</th>
									<th>Type</th>
									<th>Status</th>
									<th data-orderable="false">Actions</th>
								</tr>
							  </thead>
							  <tbody>
								<?php
								foreach( $result as $key=>$row ){ ?>
								 <tr>
									<td><?=++$key?></td>
									<td>
									  <h6 class="text-capitalize font-weight-light m-0">
										 <?=$row["f_name"]." ".$row["l_name"]?>
									  </h6>
									  <?=$row["email"];?>
									</td>
									<td><?=$row["unix_id"]?></td>
									<td class="text-capitalize"><?=$row["market"]?></a></td>
									<td><?=date('d-M-Y', strtotime($row["created_at"]))?></a></td>
									
									<td>
										<button class="btn btn-status p-0" onclick="getRoleAssigned('<?=$row["id"]?>', '<?=$row["f_name"]?>')">
										  <i class="fa fa-eye text-info"></i> View
										</button>
									</td>
									
									<td>
									   <button class="btn btn-status <?php echo $row["type"] == 1 ? 'btn-info' : 'btn-warning' ?>">
										   <?php echo $row["type"] == 1 ? 'Standard' : 'Normal' ?>
									   </button>
									</td>
									
									<td>
									   <button type="submit" class="btn btn-status <?php echo $row["status"] == 1 ? 'btn-success' : 'btn-secondary' ?>" onclick="updateStatusOnDB('<?=$row["id"]?>','dU','<?=$row["status"]?>')">
										   <?php echo $row["status"] == 1 ? 'Active' : 'Inactive' ?>
									   </button>
									</td>
									
									<td class="text-right">
										<div class="dropdown dropdown-action">
										  <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
										   <i class="fa fa-th-list ellipse_color"></i>
										  </a>
										  
										  <div class="dropdown-menu dropdown-menu-right">
											  
											  <button class="dropdown-item" onclick="editForm('<?=$row["id"]?>','dU')">
												<i class="fa fa-pencil-square-o m-r-5 text-primary"></i> Edit User
											  </button>
											  
											  <button class="dropdown-item" data-toggle="modal" data-target="#delete_asset" onclick="deleteOnDB('<?=$row["id"]?>','<?=$row["email"]?>','dU')">
											   <i class="fa fa-trash-o m-r-5 text-danger"></i> Delete User
											  </button>
											  
											  <button class="dropdown-item" onclick="AssigneOrDeleteForm('<?=$row["id"]?>','RoleGrant')">
												<i class="fa fa-plug m-r-5 text-warning"></i> Assign / Delete Role
											  </button>
											  
											  <button class="dropdown-item" onclick="AssigneOrDeleteForm('<?=$row["id"]?>','ServerGrant')">
												<i class="fa fa-cloud m-r-5 text-info"></i> Assign / Delete Server
											  </button>
										   </div>
										  </div>
										</td>
									  </tr>
								   <?php } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		 </div>
	  </div>	
   </div>
</div>

	
	
<!-- Modal's -->
 <div id="getFormModal"></div>
 <div id="getGrantModal"></div>
 <div id="getStatusModal"></div>
 <div id="getConnectionModal"></div>
<!-- Model's -->


<div class="modal fade delete-modal" id="selectColumn" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">

			<!-- Modal Header -->
			<div class="modal-header">
				<h4 class="modal-title">Column Selection</h4>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>

            <!-- Modal body -->
			<div class="modal-body" style="height: 66vh;overflow-y: auto;">
			    <form id="show_hide_column">
					<div class="row formtype">
						<?php for($k=0; $k<sizeof($column); $k++){?>
							<div class="col-md-12">
								<div class="form-group toggle-group-custom">
									<span class="text-capitalize"><?php echo str_replace('_', ' ', $column[$k]); ?></span>
									<input type="checkbox" name="<?php echo $column[$k]; ?>" data-toggle="toggle" data-style="slow" value="<?php echo $row_show_hide['column_'.$k]; ?>" <?php if($row_show_hide['column_'.$k]){echo "checked";} ?>>
								</div>
							</div>
						<?php } ?>
					</div>
				</form>
			</div>
			
		    <!-- Modal footer -->
			<div class="modal-footer float-right">
				  <button type="button" class="btn btn-danger" onclick="show_hide('Users')">Save Changes</button>
				  <button type="button" class="btn btn-dark" data-dismiss="modal">Close</button>
			</div>
						
		</div>
		 
	</div>
</div>



<!-- jQuery -->
<script>
	var element = document.getElementById("pwusers");
	   element.classList.add("active");
</script>
<?php include("includes/footer.php"); ?>
	
 
 
 <div class="row page-titles">
        <div class="col-md-5 align-self-center">
            <h4 class="text-themecolor"><?php echo TITLE ?></h4>
        </div>
        <div class="col-md-7 align-self-center text-right">
            <div class="d-flex justify-content-end align-items-center">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                    <li class="breadcrumb-item active"><?php echo TITLE ?></li>
                </ol>
				<?php
				 if(TITLE == 'Assigned Role & Permission' || TITLE == 'Requested Role'){
                   echo '<button onclick="getRoleRequestModal('.$uId.')" type="button" class="btn btn-danger d-none d-lg-block m-l-15"><i class="fa fa-plus-circle"></i> Request New Role</button>';
				 }?>
				 
				 <?php
				 if(TITLE == 'Get Password'){
				   echo '<button onclick="openModal()" type="button" class="btn btn-danger d-none d-lg-block m-l-15"><i class="fa fa-plus-circle"></i> Get Password</button>';
				 }?>
            </div>
        </div>
    </div>
	
	
	

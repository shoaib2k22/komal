<?php
define('TITLE', 'Assigned Role & Permission');
define('PAGE', 'role');

include('controller/include.php');

?>
  

 <div class="row">
	<div class="col-12">
		<div class="card">
			<div class="card-body">
				
				<div class="table-responsive">
				   <table class="table align-items-center table-flush data-table" id="dbtable">
					  <thead class="thead-light text-center">
					   <tr>
						  <th scope="col">#</th>
						  <th scope="col">Role</th>
						  <th scope="col">Market</th>
						  <th scope="col">Assigned Date</th>
						  <th scope="col">Status</th>
						  <th scope="col" data-orderable="false">Server</th>
						  <!--<th scope="col">Get Password</th>-->
						</tr>
					 </thead>
					  
					 <tbody class="text-center">
					  <?php $count = 0;
						while($row = $result->fetch_assoc()){ ?>
						<tr role="row">
							<td scope="row"><?php echo ++$count;?></td>
							<td><?php echo $row["role"]; ?></td>
							<td><?=$row["market"]?></td>
							<td><?=date("d-M-Y",strtotime($row["created_at"]))?></td>
							<td>
							  <span class="badge <?=($row["status"]==1)? 'badge-success' : 'badge-danger';?> w-100 text-white font-bold cursor-pointer blockUnblockDetele"><?=($row["status"]==1)? 'Active' : 'Blocked';?></span>
							</td>
							<td>
							  <button class="contents" onclick="viweServer('<?=$row["rId"]?>','<?=$row["role"]?>','<?=$row["market_id"]?>')"><i class="far fa-eye text-info"></i> View
							  </button>
							</td>
							<!--
							<td>
							  <button class="btn btn-danger mr-3" onclick="getDetails('<?=$row["role"]?>','<?=$row["market"]?>')">Get Password</button>
							</td>
							-->
						</tr>
					   <?php } ?>
					 </tbody> 
				  </table>
			   </div>
		   </div>
	   </div>
    </div>
 </div>




<!-- The Modal -->
<div id="getPasswordRequestModal"></div>
<div id="alertMsg"></div>
<!-- Model -->



<?php 
  include('layout/footer.php'); 
  $conn->close();
?>
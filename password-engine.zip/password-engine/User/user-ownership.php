<?php
define('TITLE', 'User Ownership');
define('PAGE', 'userOwnership');

include('controller/include.php');
 
?>

<style>

button:focus {
    outline: 1px dotted;
    outline: 0px auto -webkit-focus-ring-color;
}


.tabs button.tab {
  position: relative;
  display: table-cell;
  transition: all ease 0.3s;
  padding: 1em 1.6em;
  transform: translate3d(0, 0, 0);
  color: #636d84;
  white-space: nowrap;
  cursor: pointer;
  border: 0px;
  background: #ff000000;
}
.tabs button.tab:hover {
  color: #DC3545;
}
.tabs button.tab:after {
  transition: all 0.5s cubic-bezier(0, 0, 0, 0);
  will-change: transform, box-shadow, opacity;
  position: absolute;
  content: "";
  height: 3px;
  bottom: 0px;
  left: 0px;
  right: 0px;
  border-radius: 3px 3px 0px 0px;
  background: #DC3545;
  box-shadow: 0px 4px 10px 3px rgba(60, 180, 250, 0.15);
  opacity: 0;
  transform: scale(0, 1);
}
.tabs button.tab.active {
  color: #DC3545;
}
.tabs button.tab.active:after {
  opacity: 1;
  transform: scale(1, 1);
}

.hide{
	display:none;
}
</style>

<div class="tabs">
	<button class="tab active" onclick="show(this);" key="account-owner">Account Owner</button>
	<button class="tab" onclick="show(this);" key="account-owner-list">Account Owner List</button>
</div>
    

<div class="row">
   <div class="col-12">
      <div class="card">
			<div class="card-body">
			  <div class="table-responsive" id="account-owner">
				<table class="table align-items-center table-flush data-table" id="dbtable">
					<thead>
						<tr>
							<th>#</th>
							<th>Server</th>
							<th>Service / Functional User</th>
							<th>Created On</th>
							<th class="text-right pr-5">Actions</th>
						</tr>
					</thead>
					<tbody>
					 <?php
					   foreach( $result as $key=>$row ){ ?>
						<tr>
							<td><?=++$key?></td>
							
							<td><?=$row["host_name"]?></td>
							
							<td><?=$row["user"]?></td>
							
							<td><?=date('d-M-Y', strtotime($row["created_at"]))?></td>
							
							<?php
								if($row['status']==0){ $status = 'Pending'; $btnColor = 'btn-warning'; $icon = 'fa fa-clock';}
								if($row['status']==1){ $status = 'Approved'; $btnColor = 'btn-success'; $icon = 'fa fa-check';}
								if($row['status']==2){ $status = 'Declined'; $btnColor = 'btn-danger'; $icon = 'fa fa-ban';}
							?>
							
							<td class="text-right">
							    <div class="btn-group open">
									<a class="btn <?=$btnColor?>" href="#"><i class="<?=$icon?> fa-fw"></i> <?=$status?>
									</a>
									<a class="btn <?=$btnColor?>" data-toggle="dropdown" href="#">
										<span class="fa fa-caret-down" title="Toggle dropdown menu"></span>
									</a>
								  
								    <div class="dropdown-menu dropdown-menu-right">
									  
									  <button class="dropdown-item" onclick="updateStatus('Pending', <?=$row['id']?>, 'Su')" <?php if($row['status']==0){ echo "disabled"; } ?>>
										<i class="fa fa-clock m-r-5 text-warning"></i>Pending
									  </button>
									  
									  <!--
									  <button class="dropdown-item" onclick="updateStatus('Approve', <?=$row['id']?>, 'Su')" <?php if($row['status']==1){ echo "disabled selected"; } ?>>
									   <i class="fa fa-check-square m-r-5 text-success"></i>Approve
									  </button>
									  -->
									  
									  <button class="dropdown-item" onclick="getApproveDetails('Approve', <?=$row['id']?>, 'Su')" <?php if($row['status']==1){ echo "disabled selected"; } ?>>
									   <i class="fa fa-check-square m-r-5 text-success"></i>Approve
									  </button>
									  
									  <button class="dropdown-item" onclick="updateStatus('Decline', <?=$row['id']?>, 'Su')" <?php if($row['status']==2){ echo "disabled selected"; } ?>>
										<i class="fa fa-ban m-r-5 text-danger"></i>Decline
									  </button>
									  
									</div>
								</div>
							</td>
						</tr>
					   <?php } ?>
					</tbody>
				</table>
			</div>
			<div class="hide table-responsive" id="account-owner-list">
				<table class="table align-items-center table-flush data-table" id="dbtable">
					<thead>
						<tr>
							<th>#</th>
							<th>Server</th>
							<th>Service / Functional User</th>
							<th>Created On</th>
							<th>List View</th>
						</tr>
					</thead>
					<tbody>
					 <?php
					   foreach( $result as $key=>$row ){ ?>
						<tr>
							<td style="width: 11%;"><?=++$key?></td>
							
							<td style="width: 15%;"><?=$row["host_name"]?></td>
							
							<td><?=$row["user"]?></td>
							
							<td><?=date('d-M-Y', strtotime($row["created_at"]))?></td>
							
							<td>
							  <button class="btn btn-status p-0" onclick="getUser('<?=$row["user"]?>', '<?=$row["host_name"]?>')">
								<i class="fa fa-eye text-info"></i> View
							  </button>
							</td>
						</tr>
					   <?php } ?>
					</tbody>
				</table>
			</div>
		 </div>
	   </div>
    </div>
  </div>
</div>

<div id="getModal"></div>
   
	
<?php 
  include('layout/footer.php'); 
  $conn->close();
?>

<script>
function show(e){
	$(".tab").removeClass('active');
	$(e).addClass('active');
	$(".table-responsive").hide();
	let key = $(e).attr("key");
	$("#"+key).show();
}
</script>
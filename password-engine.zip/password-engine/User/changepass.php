<?php
define('TITLE', 'Change Password');
define('PAGE', 'changepass');

include('controller/include.php');
 
?>


<div class="col-sm-9 col-md-10">
  <div class="row">
    <div class="col-sm-6">
      <form class="mt-5 mx-5">
		<div class="form-group">
          <label for="old_Password">Old Password</label>
          <input type="password" class="form-control" id="old_Password" placeholder="Old Password" name="old_Password">
        </div>
		<div class="form-group">
          <label for="new_Password">New Password</label>
          <input type="password" class="form-control" id="new_Password" placeholder="New Password" name="new_Password">
        </div>
        <div class="form-group">
          <label for="confirm_Password">Confirm Password</label>
          <input type="password" class="form-control" id="confirm_Password" placeholder="Confirm Password" name="confirm_Password">
        </div>
        <button type="submit" class="btn btn-danger mr-4 mt-4" name="passupdate">Update</button>
        <button type="reset" class="btn btn-secondary mt-4">Reset</button>
        <?php if(isset($passmsg)) {echo $passmsg; } ?>
      </form>
    </div>
  </div>
</div>
</div>
</div>

<?php
include('layout/footer.php'); 
?>
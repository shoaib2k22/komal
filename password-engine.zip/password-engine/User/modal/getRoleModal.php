<?php
include('../../dbConnection.php');

$market=$_POST['market'];
?>

 <label for="server">Select Role</label>
 <select class="item inn form-control" name="role" id="role" onchange="getServer(this.value)"> 
	  <option value="" disabled selected>Select Role</option> 
		<?php 
		  $rSql = "SELECT * FROM roles WHERE status = 1";   
		  $rResult = $conn->query($rSql);			    
		  while($rRow = mysqli_fetch_array($rResult)) { ?> 
			  <option value="<?php echo $rRow['id']; ?>"><?php echo $rRow['role']; ?></option>
	   <?php } ?>				 
 </select>
<?php

header('Content-Type:application/json');
header('Acess-Control-Allow-Origin: *');

include('../dbConnection.php');

$sql = "select * from users";
$result = mysqli_query($conn,$sql);
$count = mysqli_num_rows($result);

if($count>0){
	while($row = mysqli_fetch_assoc($result)){
		$arr[] = $row;
	}
	echo json_encode(['status'=>'true', 'data'=>$arr, 'result'=>'true']);
}
else{
	echo json_encode(['status'=>'true', 'data'=>'No record found', 'result'=>'false']);
}

?>
<?php

header('Acess-Control-Allow-Origin: *');
header('Acess-Control-Allow-Credentials: true');
header('Acess-Control-Allow-Methods: GET,POST,OPTIONS');
header('Acess-Control-Allow-Headers: *');
header('Content-Type:application/json');


/*
$connection = ssh2_connect('vgg218yr', 22);
ssh2_auth_password($connection, 'alive007', 'Acc@0323');
$stream = ssh2_exec($connection, 'whoami');

stream_set_blocking($stream, true);
   $output = ssh2_fetch_stream($stream, SSH2_STREAM_STDIO);
   echo stream_get_contents($output);
*/


$client_ip = $_SERVER['REMOTE_ADDR'];
$data = json_decode(file_get_contents("php://input"),true);

$Key = trim(isset($data['Key']) ? $data['Key'] : $_REQUEST['Key']);

include('../dbConnection.php');

$sql_key = "SELECT * FROM password_encryption WHERE encrypt_key = '$Key'";
$result_key = mysqli_query($conn,$sql_key);
$row_key = mysqli_fetch_assoc($result_key);

	if(!$row_key){
		echo "validation failed, Invalid key, Status: 400";
		exit;
	}

$decrypted_key = decrypt($Key,$row_key['secure_key']);
$obj = json_decode("$decrypted_key");

$SourceServerName = $obj->sourceServer;
$SourceUserName = $obj->sourceUser;
$TargetServerName = $obj->targetServer;
$TargetUserName = $obj->targetUser;


$sql_source = "SELECT *, servers.id AS ssID, server_users.id AS suID FROM servers, server_users WHERE server_users.user = '$SourceUserName' AND servers.host_name = '$SourceServerName' AND servers.id = server_users.server_id";
$result_source = mysqli_query($conn,$sql_source);
$row_source = mysqli_fetch_assoc($result_source);

	if(!$row_source){
		echo "validation failed, Please verify your SourceUserName and SourceServerName, Status: 400";
		exit;
	}
	
	if($row_source['ip_address']!= $client_ip){
     echo "Invalid request, Status: 400";
     exit;
	}


$sql_target = "SELECT *,servers.id AS tsID, server_users.id AS tuID, server_users.password AS pass, server_users.secure_key AS sk, server_users.status AS status FROM servers, server_users WHERE server_users.user = '$TargetUserName' AND servers.host_name = '$TargetServerName' AND servers.id = server_users.server_id";
$result_target = mysqli_query($conn,$sql_target);
$row_target = mysqli_fetch_assoc($result_target);

   if(!$row_target){
		echo "validation failed, Please verify your TargetUserName and TargetServerName, Status: 400";
		exit;
	}
	
	if($row_target['host_name'] == $row_source['host_name']){
		echo "validation failed, Source server and Target server could not be same, Status: 400";
		exit;
	}
	
	echo $password = decrypt($row_target['pass'],$row_target['sk']);


/*	
$source_server_id = $row_source['ssID'];
$source_user_id = $row_source['suID'];
$target_server_id = $row_target['tsID'];
$target_user_id = $row_target['tuID'];


$sql_match = "SELECT * FROM password_encryption WHERE source_server_id = $source_server_id AND source_user_id = $source_user_id AND target_server_id = $target_server_id AND target_user_id = $target_user_id";
$result_match = mysqli_query($conn,$sql_match);
$row_match = mysqli_fetch_assoc($result_match);


if($row_match['encrypt_key']!=trim($Key)){
	echo json_encode(
		 array(
			'result'=> "validation failed",
			'message'=> "Your are passing invalid key",
			'status'=> 400
			));
		 exit;
}

$decrypted_key = decrypt($Key,$row_match['secure_key']);
$obj = json_decode("$decrypted_key");


if(!$row_match){
		echo json_encode(
		 array(
			'result'=> "validation failed",
			'message'=> "Please verify your input data",
			'status'=> 400
			));
		 exit;
	}
	
if($SourceServerName != $obj->sourceServer && $SourceUserName != $obj->sourceUser && $TargetServerName != $obj->targetServer && $TargetUserName != $obj->targetUser){
     echo json_encode(
		 array(
			'result'=> "validation failed",
			'message'=> "Your key is invalid",
			'status'=> 400
			));
		 exit;
	}

	
if($row_target['status'] == 0){
	echo json_encode(
		 array(
			'result'=> "success",
			'message'=> "This target user is in pending status, Please try once approve",
			'status'=> 400
			));
		 exit;
	}
	
	
if($row_target['status'] == 2){
	echo json_encode(
		 array(
			'result'=> "success",
			'message'=> "This target user has been declined",
			'status'=> 400
			));
		 exit;
	}
	

echo $password = decrypt($row_target['pass'],$row_target['sk']);

   /*
   echo json_encode(
		   array(
			'password'=> $password,
			'result'=> "success",
			'message'=> "validation true",
			'status'=> 200
		));
    */


function decrypt($message,$encryption_key){
	$key = $encryption_key;
	$message = base64_decode(urldecode($message));
	$nonceSize = openssl_cipher_iv_length('aes-256-ctr');
	$nonce = mb_substr($message, 0, $nonceSize, '8bit');
	$ciphertext = mb_substr($message, $nonceSize, null, '8bit');

	$plaintext= openssl_decrypt(
	  $ciphertext, 
	  'aes-256-ctr', 
	  $key,
	  OPENSSL_RAW_DATA,
	  $nonce
	);
	
  return $plaintext;
}


?>
<?php
 
/* $data = array(
    'ServerName' => 'oo',
    'Username' => 'john.doe@example.com',
    'Password' => '1234567890'
);

$json = json_encode($data); */

//curl -k -u  "VF-ROOT\LIVE008IA":"Password" -X POST -H "Content-Type:application/json" -d @input.json "https://oo.vodafone.com/oo/rest/v2/executions"

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://oo.vodafone.com/oo");
curl_setopt($ch, CURLOPT_POST, 0);
curl_setopt($ch, CURLOPT_HTTPGET, 1);
curl_setopt($ch, CURLOPT_PORT, 22);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
//curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json'
));
 
$response = curl_exec($ch);
if(curl_errno($ch)) {
    echo 'Error: ' . curl_error($ch);
} else {
    echo $response;
}
curl_close($ch);
 
?>
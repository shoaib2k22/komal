<?php

$connection = ssh2_connect('vgssh3hr', 22);

if (ssh2_auth_password($connection, 'alive007', 'Acc@0623')) {
  echo exec('hostname');

} else {
  die('Authentication Failed...');
}

/*$connection = ssh2_connect('vg4044yr', 22);

if (ssh2_auth_password($connection, 'alive007', 'Acc@0623')) {
  echo exec('hostname');

} else {
  die('Authentication Failed...');
}*/

?>